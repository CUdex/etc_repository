#!/bin/sh

CENTERDOMAIN=$1
IP1=$2
IP2=$3
if [ "x$4" = "x" ] ; then
	TIMEOUT=30
else
	TIMEOUT=$4
fi

ERRCOUNT=0

if [ "x$#" != "x3" ] ; then
	echo "Usage: healthcheck.sh domainname masterip slaveip"
	exit
fi

ACTIVEIP=`cat /etc/hosts | grep $CENTERDOMAIN | awk '{print $1}'`

if [ "x$ACTIVEIP" == "x$IP2" ]; then
	BACKUPIP=$IP1
else
	ACTIVEIP=$IP1
	BACKUPIP=$IP2
fi

cat /etc/hosts | grep -v $CENTERDOMAIN > /tmp/hosts
mv -f /tmp/hosts /etc/hosts
echo "$ACTIVEIP $CENTERDOMAIN" >> /etc/hosts

while [ true ] ; do
	ping -c 1 -W 2 $ACTIVEIP > /dev/null
	if [ $? != 0 ] ; then
		ERRCOUNT=`expr $ERRCOUNT + 1`
		echo $ACTIVEIP is dead. count=$ERRCOUNT
		if [ $ERRCOUNT -ge $TIMEOUT ] ; then
			OLDACTIVEIP=$ACTIVEIP
			ACTIVEIP=$BACKUPIP
			BACKUPIP=$OLDACTIVEIP

			cat /etc/hosts | grep -v $CENTERDOMAIN > /tmp/hosts
			mv -f /tmp/hosts /etc/hosts
			echo "$ACTIVEIP $CENTERDOMAIN" >> /etc/hosts
			echo MASTERIP changed. OLD=$OLDACTIVEIP NEW=$ACTIVEIP
			ERRCOUNT=0
		fi  
	else
		echo $ACTIVEIP is alive
		ERRCOUNT=0
	fi  
	sleep 1
done

