#!/bin/sh

if [ "x${1}" = "x" ] ; then
	echo "usage: checkgwsimg.sh [image]"
	exit
fi

if [ ! -f ${1} ] ; then
	echo "image file not found"
	exit
fi

TOTSIZE=`ls -l ${1} | awk '{print $5}'`
IMGSIZE=`expr $TOTSIZE - 40`
CHECKSUM1=`dd if=${1} bs=1 count=40 skip=${IMGSIZE} 2> /dev/null`
CHECKSUM2=`dd if=${1} bs=$IMGSIZE count=1 2> /dev/null | sha1sum | cut -c -40`

if [ "x$CHECKSUM1" != "x" ] && [ "$CHECKSUM1" = "$CHECKSUM2" ] ; then
	echo OK
	exit 0;
else
	echo FAIL
	exit 1;
fi
