#!/bin/sh

if [ "x$1" == "x" ] ; then
DIRS=`ls /disk/data/patches`
else
DIRS=$1
fi

for DN in $DIRS ; do
	echo "Checking directory $GN"

	FILES=`ls /disk/data/patches/$DN`

	for FN in $FILES ; do
		RESULT=`/bin/sha1sum /disk/data/patches/$DN/$FN`
		HASH1=`echo $RESULT | awk '{print $1}'`
		HASH2=`echo $RESULT | awk '{print $2}'`
		HASH3=`basename $HASH2`
		HASH4=`echo $HASH3 | awk -F'.' '{print tolower($1)}'`

		if [ $HASH1 != $HASH4 ] ; then
			echo "$FN ($HASH1) DIFF !!!"
		fi
	done
done
