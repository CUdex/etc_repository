#!/bin/bash

LOCALCONF=/disk/sys/conf/local.conf
CLOGINPASS=/disk/sys/conf/CLOGINPASS
issensor=0
iswsensor=0

function valid_ip()
{
	local  ip=$1
	local  stat=1

	if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
		OIFS=$IFS
		IFS='.'
		ip=($ip)
		IFS=$OIFS
		[[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
			&& ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
		stat=$?
	fi
	return $stat
}

echo ""
echo "Genian NAC Initial Configuration Tool"

# Installation Type

if [ "x$COMMUNITY" = "x1" ] ; then
	insttype=1
else
	while [ true ] ; do
		echo ""
		echo "1. Interactive Wizard"
		echo "2. Manual Configuration"
		echo ""
		echo -n "Select installation type: "
		read -e insttype
		if [ "x$insttype" = "x1" ] || [ "x$insttype" = "x2" ] ; then
			break;
		fi
		echo "Invalid choice"
	done
fi

if [ "x$insttype" = "x1" ] ; then

	# Server Type

	if [ -f /usr/geni/centerd ] ; then
		if [ "x$COMMUNITY" = "x1" ] ; then
			frontend=1
			backend=1
		else
			STYPE[1]="Single Server - Stand Alone"
			STYPE[2]="Multi Server - Backend (Log/Database Server)"
			STYPE[3]="Multi Server - Frontend (Node/Mgmt Server)"

			while [ true ] ; do
				echo ""
				echo 1. ${STYPE[1]}
				echo 2. ${STYPE[2]}
				echo 3. ${STYPE[3]}
				echo ""
				echo -n "Select Server Type: "
				read -e stype
				if [ "x$stype" = "x1" ] || [ "x$stype" = "x2" ] || [ "x$stype" = "x3" ] ; then
					stypename=${STYPE[$stype]}
					break;
				fi
				echo "Invalid choice"
			done

			if [ "x$stype" = "x1" ] || [ "x$stype" = "x3" ] ; then
				frontend=1
			else
				frontend=0
			fi
			if [ "x$stype" = "x1" ] || [ "x$stype" = "x2" ] ; then
				backend=1
			else
				backend=0
			fi
			sensor=0
		fi
	else
		fronend=0
		backend=0
		sensor=1
	fi

	# System Language

	if [ "x$COMMUNITY" = "x1" ] ; then
		slangname=English
		slangcode=en
	else
		SLANG[1]="English"
		SLANG[2]="Korean"
		SLANGCODE[1]="en"
		SLANGCODE[2]="ko"

		if [ "x$frontend" = "x1" ] ; then
			while [ true ] ; do
				echo ""
				echo 1. ${SLANG[1]}
				echo 2. ${SLANG[2]}
			echo ""
				echo -n "Select System Language: "
				read -e lang
				if [ "x$lang" = "x1" ] || [ "x$lang" = "x2" ] ; then
					slangname=${SLANG[$lang]}
					slangcode=${SLANGCODE[$lang]}
					break;
				fi
				echo "Invalid choice"
			done
		fi
	fi
	
	# EULA

	EULA=/usr/geni/eula-${slangcode}.txt

	if [ -f $EULA ] ; then
		more $EULA
		echo ""
		while [ true ] ; do
			echo    "If you agree to the above terms type 'yes'."
			echo -n "Otherwise type 'no' to cancel installation: "
			read -e answer
			if [ "x$answer" = "xyes" ] || [ "x$answer" = "xno" ] ; then
				break;
			fi
		done

		if [ "x$answer" != "xyes" ] ; then
			exit
		fi
	fi
fi

# Console Username

while [ true ] ; do
	echo ""
	echo -n "Enter Console Username (31 characters max) [admin]: "
	read -e username
	if [ "x$username" = "x" ] ; then
		username=admin
	fi
	if [ "${#username}" -lt "4" ] ; then
		continue
	fi
	if [ "${#username}" -gt "31" ] ; then
		continue
	fi
	break;
done

# Console Password

while [ true ] ; do
	echo ""
	echo "# Password must contain at least one alphabet, number, and special character"
	echo -n "Enter Console Password (9 to 32 characters): "
	read -es password
	if [ "${#password}" -lt "9" ] ; then
		continue
	fi
	chkstr=`echo $password | sed 's/[0-9]//g'`
	if [ "x$password" = "x$chkstr" ] ; then
		continue
	fi
	chkstr=`echo $password | sed 's/[a-zA-Z]//g'`
	if [ "x$password" = "x$chkstr" ] ; then
		continue
	fi
	chkstr=`echo $password | sed 's/[a-zA-Z0-9]//g'`
	if [ "x$chkstr" = "x" ] ; then
		continue
	fi

	echo ""
	echo -n "Try Again: "
	read -es retry
	if [ "x$password" != "x$retry" ] ; then
		echo ""
		echo "Password Mismatched"
		continue
	fi
	break;
done

echo ""

if [ "x$insttype" = "x2" ] ; then
	echo ""

	CPASS=`echo -n $password | sha256sum | awk '{print $1}'`
	echo "$username:$CPASS" > $CLOGINPASS

	echo "Welcome to Genian NAC"
	echo ""

	exit
fi

# Timezone

TZCONS="Africa America Antarctica Asia Arctic Australia Europe Indian Pacific"

while [ true ] ; do
	echo ""

	NUM=1
	for NAME in $TZCONS ; do
		printf "%3d. %-20s" $NUM $NAME
		DIV=`expr $NUM % 3`
		if [ $DIV = "0" ] ; then
			echo ""
		fi
		NUM=`expr $NUM + 1`
	done

	echo ""
	echo -n "[Timezone] Select Continental: "
	read -e tzcon
	if [ "x$tzcon" = "x" ] ; then
		continue;
	fi
	if [ "$tzcon" -gt "0" ] && [ "$tzcon" -lt "11" ] ; then
		NUM=1
		for NAME in $TZCONS ; do
			if [ "$tzcon" = "$NUM" ] ; then
				tzcon=$NAME
				break;
			fi 
			NUM=`expr $NUM + 1`
		done
		break
	fi
	echo "Invalid choice"
done

TZCITY=`ls /usr/share/zoneinfo/$tzcon`

while [ true ] ; do
	echo ""

	rm -f /tmp/tzcity.txt

	NUM=1
	for NAME in $TZCITY ; do
		printf "%3d. %-20s" $NUM $NAME >> /tmp/tzcity.txt
		DIV=`expr $NUM % 3`
		if [ $DIV = "0" ] ; then
			echo "" >> /tmp/tzcity.txt
		fi
		NUM=`expr $NUM + 1`
	done

	if [ $DIV != "0" ] ; then
		echo "" >> /tmp/tzcity.txt
	fi

	more /tmp/tzcity.txt

	echo ""
	echo -n "[Timezone] Select City (press enter for re-display): "
	read -e tzcity
	if [ "x$tzcity" = "x" ] ; then
		continue;
	fi

	if [ "$tzcity" -gt "0" ] && [ "$tzcity" -lt "$NUM" ] ; then
		NUM=1
		for NAME in $TZCITY ; do
			if [ "$tzcity" = "$NUM" ] ; then
				tzcity=$NAME
				break;
			fi
			NUM=`expr $NUM + 1`
		done
		break;
	fi
	echo "Invalid choice"
done

rm -f /tmp/tzcity.txt
echo Selected Timezone is $tzcon/$tzcity

# NTP Server

if [ "x$COMMUNITY" = "x1" ] ; then
	ntpserver=pool.ntp.org
else
	echo ""
	echo -n "Enter NTP server [pool.ntp.org]: "
	read -e ntpserver
	if [ "x$ntpserver" = "x" ] ; then
		ntpserver=pool.ntp.org
	fi
fi

# Network Interface Port Number

NUMIF=`cat /proc/net/dev | grep eth | wc -l`
NUMWIF=`cat /proc/net/dev | grep wlan | wc -l`

if [ "x$NUMIF" = "x0" ] ; then
	echo "Network interface card not found. check your hardware."
	read pause
	exit
elif [ "x$NUMIF" = "x1" ] ; then
	ifnum=0
else
	while [ true ] ; do
		echo ""
		NUM=0
		while [ true ] ; do
			IFN=eth$NUM
			printf "%d. %-20s\n" $NUM $IFN
			NUM=`expr $NUM + 1`
			if [ "$NUM" -ge "$NUMIF" ] ; then
				break
			fi
		done
		echo ""
		echo -n "Select Network Interface: "
		read -e ifnum
		if [ "x$ifnum" = "x" ] ; then
			continue
		fi
		if [ "$ifnum" -ge "0" ] && [ "$ifnum" -lt "$NUM" ] ; then
			break;
		fi
	done
fi

echo ""
echo "Network Setup for eth$ifnum"

# IP Address

while [ true ] ; do
	echo ""
	echo -n "Enter IP Address: "
	read -e ipaddr
	if valid_ip $ipaddr ; then
		break
	fi
	echo "Invalid IP Address"
done

# Netmask

while [ true ] ; do
	echo ""
	echo -n "Enter Netmask [255.255.255.0]: "
	read -e netmask
	if [ "x$netmask" = "x" ] ; then
		netmask=255.255.255.0
	fi
	if valid_ip $netmask ; then
		break
	fi
	echo "Invalid Netmask"
done

# Gateway

while [ true ] ; do
	echo ""
	echo -n "Enter Default Gateway: "
	read -e gateway
	if valid_ip $gateway ; then
		break
	fi
	echo "Invalid Default Gateway"
done

# DNS

while [ true ] ; do
	echo ""
	echo -n "Enter DNS Server IP Address(es) (seperated by comma): "
	read -e dns
	if valid_ip $dns ; then
		break
	fi

    IFS=','
    invalid=0
    for IP in $dns ; do
        if ! valid_ip $IP ; then
            invalid=1
        fi
    done
    if [ $invalid = "1" ] ; then
        echo "Invalid DNS Server IP Address"
    else
        break
    fi
done

# Sensor Enable (StandAlone)

if [ "x$frontend" = "x1" ] && [ "x$backend" = "x1" ] ; then
	while [ true ] ; do
		echo ""
		echo -n "Do you want to configure 'eth$ifnum' as a wired network sensor (Y/n) ? "
		read -e issensor
		if [ "x$issensor" = "x" ] || [ "x$issensor" = "xy" ] || [ "x$issensor" = "xY" ] ; then
			issensor=1
			break;
		fi
		if [ "x$issensor" = "xn" ] || [ "x$issensor" = "xN" ] ; then
			issensor=0
			break;
		fi
	done

	if [ "x$NUMWIF" != "x0" ] ; then
		while [ true ] ; do
			echo ""
			echo -n "Do you want to configure 'wlan0' as a wireless network sensor (Y/n) ? "
			read -e iswsensor
			if [ "x$iswsensor" = "x" ] || [ "x$iswsensor" = "xy" ] || [ "x$iswsensor" = "xY" ] ; then
				iswsensor=1
				break;
			fi
			if [ "x$iswsensor" = "xn" ] || [ "x$iswsensor" = "xN" ] ; then
				iswsensor=0
				break;
			fi
		done
	fi
fi

# Node Server IP

neednsip=0
if [ "x$backend" = "x1" ] && [ "x$frontend" != "x1" ] ; then
	neednsip=1
fi
if [ "x$sensor" = "x1" ] ; then
	neednsip=1
fi
if [ "x$neednsip" = "x1" ] ; then
	while [ true ] ; do
		echo ""
		echo -n "Enter Policy Center IP Address: "
		read -e frontendip
		if valid_ip $frontendip ; then
			break
		fi
		echo "Invalid Frontend Server IP Address"
	done
fi

if [ "x$frontend" = "x1" ] && [ "x$backend" != "x1" ] ; then
	while [ true ] ; do
		echo ""
		echo -n "Enter Backend(Database) Server IP Address: "
		read -e backendip
		if valid_ip $backendip ; then
			break
		fi
		echo "Invalid Backend Server IP Address"
	done

	while [ true ] ; do
		echo ""
		echo -n "Enter Backend Database Server Password: "
		read -e DBPASS
		if [ "x$DBPASS" != "x" ] ; then
			ENCPASS=`aes256 -e $DBPASS`
			break
		fi
	done
fi

# Summary

echo ""
echo "Configuration Summary"
echo "----------------------------------------------------------------"
echo "Server Type:                    $stypename"
if [ "x$frontend" = "x1" ] ; then
	echo "System Language:                $slangname"
fi
echo "Console Username:               $username"
echo "Timezone:                       $tzcon/$tzcity"
echo "NTP Server:                     $ntpserver"
echo "Network Interface:              eth$ifnum"
echo "IP Address:                     $ipaddr"
echo "Netmask:                        $netmask"
echo "Default Gateway:                $gateway"
if [ "x$issensor" = "x1" ] ; then
	echo "Enable Wired Network Sensor:    yes"
else
	echo "Enable Wired Network Sensor:    no"
fi
if [ "x$iswsensor" = "x1" ] ; then
	echo "Enable Wireless Network Sensor: yes"
else
	echo "Enable Wireless Network Sensor: no"
fi
echo "DNS Server IP Address:          $dns"
if [ "x$backend" = "x1" ] && [ "x$frontend" != "x1" ] ; then
	echo "Frontend Server IP Address:     $frontendip"
fi
if [ "x$frontend" = "x1" ] && [ "x$backend" != "x1" ] ; then
	echo "Backend Server IP Address:      $backendip"
fi
if [ "x$backend" = "x1" ] ; then
	DBPASS=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | dd bs=8 count=1 2> /dev/null`
	ENCPASS=`aes256 -e $DBPASS`
	echo "Database Server Password:       $DBPASS"
fi
echo "----------------------------------------------------------------"

echo ""
while [ true ] ; do
	echo -n "Are you sure to continue (y/n) ? "
	read -e confirm
	if [ "x$confirm" = "xy" ] || [ "x$confirm" = "xn" ] ; then
		break;
	fi
done

if [ "x$confirm" = "xn" ] ; then
	clear
	/usr/geni/tools/initial_setup.sh
	exit
fi

# Generate local.conf

CPASS=`echo -n $password | sha256sum | awk '{print $1}'`
echo "$username:$CPASS" > $CLOGINPASS

echo -n "" > $LOCALCONF

if [ "x$backend" = "x1" ] ; then
	echo "data-server=enable" >> $LOCALCONF
	echo "data-server_password=$ENCPASS" >> $LOCALCONF
	echo "data-server_username=root" >> $LOCALCONF
else
	if [ "x$sensor" = "x0" ] ; then
		echo "data-server_ip=$backendip" >> $LOCALCONF
		echo "data-server_password=$ENCPASS" >> $LOCALCONF

		cat /etc/hosts | grep -v dbserver | grep -v logserver > /tmp/hosts
		echo "$backendip dbserver" >> /tmp/hosts
		echo "$backendip logserver" >> /tmp/hosts
		cat /tmp/hosts > /etc/hosts
	fi
fi

echo "debug_centerd_category=0xffffffff" >> $LOCALCONF
echo "debug_centerd_field=0x319" >> $LOCALCONF
echo "debug_sensord_category=0xffffffff" >> $LOCALCONF
echo "debug_sensord_field=0x319" >> $LOCALCONF

echo "interface_eth${ifnum}_address=$ipaddr $netmask" >> $LOCALCONF
echo "interface_eth${ifnum}_gateway=$gateway" >> $LOCALCONF
if [ "x$frontend" = "x1" ] ; then
	echo "interface_eth${ifnum}_management-server=enable" >> $LOCALCONF
	echo "interface_eth${ifnum}_node-server=enable" >> $LOCALCONF
fi
if [ "x$frontend" = "x1" ] && [ "x$backend" = "x1" ] ; then
	echo "interface_eth${ifnum}_radius-server=enable" >> $LOCALCONF
fi

if [ "x$iswsensor" = "x1" ] ; then
	echo "interface_wlan0_mode=monitor" >> $LOCALCONF
fi

echo "ip_default-gateway=$gateway" >> $LOCALCONF
echo "ip_name-server=$dns" >> $LOCALCONF

if [ "x$backend" = "x1" ] ; then
	echo "log-server=enable" >> $LOCALCONF
	echo "log-server_cluster-name=GENIAN" >> $LOCALCONF
else
	if [ "x$sensor" = "x0" ] ; then
		echo "log-server_cluster-name=GENIAN" >> $LOCALCONF
		echo "log-server_ip=$backendip" >> $LOCALCONF
	fi
fi

echo "ntp_server=$ntpserver" >> $LOCALCONF

if [ "x$neednsip" = "x1" ] ; then
	echo "node-server_ip=$frontendip" >> $LOCALCONF
fi

if [ "x$frontend" = "x1" ] ; then
	echo "system-locale=$slangcode" >> $LOCALCONF
fi

# Timezone

ln -sf /usr/share/zoneinfo/$tzcon/$tzcity /disk/sys/conf/localtime
echo "$tzcon/$tzcity" > /disk/sys/conf/TIMEZONE

# Name Server

OIFS=$IFS
IFS=","
for IP in $dns ; do
	if [ "x$DNSCONF" != "x" ]; then
		DNSCONF+="\n"
	fi
	DNSCONF+=$(echo "nameserver $IP")
done
IFS=$OIFS

if [ "x$DNSCONF" != "x" ]; then
	printf "$DNSCONF" > /etc/resolv.conf
fi

# Sensor Enable

if [ "x$issensor" = "x1" ] ; then
	touch /disk/sys/conf/ENABLE_DEFAULT_SENSOR
fi

# Starting NAC

echo ""
echo -n "Checking Network Interface....."
/etc/init.d/ifsetup > /dev/null 2>&1
ping -c 10 $gateway > /dev/null
if [ "x$?" = "x0" ] ; then
	echo " Success"
else
	echo " Failed (Gateway Unreachable)"
fi

# NTP Sync

echo ""
echo -n "Time sync from $ntpserver...."
NTPMSG=`/bin/ntpdate $ntpserver`
/usr/geni/tools/updatehwclock.sh
echo ""
echo $NTPMSG

# Starting NAC

echo ""
echo -n "Starting Genian NAC....."
/etc/init.d/alder stop > /dev/null 2>&1
/etc/init.d/alder start > /dev/null 2>&1

# Create Super Admin

if [ "x$frontend" = "x1" ] ; then
	if [ "x$slangcode" = "xen" ] ; then
		mysql -h dbserver -u root --password="$DBPASS" ALDER -e "UPDATE CONF SET CONF_VALUE = 'on' WHERE CONF_CATGRY = 'Advance' AND CONF_KEY = 'CommunityEnable'"
	fi

	mysql -h dbserver -u root --password="$DBPASS" ALDER -e "REPLACE INTO USER (USER_ID, USER_PASSWORD, USER_PASSCRYPTTYPE, USER_NAME, USER_STATUS, USER_APPPURPOSE, USER_CREATED, USER_LASTPWCHANGE) VALUES ('$username', GETPASS('HMAC-SHA256', '$password'), 'HMAC-SHA256', 'Super Administrator', 1, 'USER', NOW(), NOW())"

	if [ "x$COMMUNITY" = "x1" ] ; then
		ALLOWIP="0.0.0.0/0"
	else
		ALLOWIP=""
	fi

	mysql -h dbserver -u root --password="$DBPASS" ALDER -e "REPLACE INTO ADMIN (ADM_ID, ADM_PASSWORD, ADM_PASSCRYPTTYPE, ADM_ROLEID, ADM_COMMENT, ADM_EMAIL, ADM_CREATED, ADM_LOCALE, ADM_ALLOWIP1) VALUES ('$username', GETPASS('HMAC-SHA256', '$password'), 'HMAC-SHA256', 'superAdmin', 'Super Administrator', '', NOW(), '$slangcode', '$ALLOWIP')"

	NUMADMINWIDGET=`mysql -B -N -h dbserver --password="$DBPASS" -u root --skip-column-names ALDER -e "SELECT COUNT(*) FROM WidgetLayout WHERE AdminID='$username'"`
	if [ "x$NUMADMINWIDGET" = "x0" ] ; then
		mysql -h dbserver -u root --password="$DBPASS" ALDER -e "INSERT INTO WidgetLayout (AdminID, TabID, PanelID, WidgetID, WidgetOrder, WidgetParams) SELECT '$username', (SELECT CONFUI_DISP FROM vwCONFUI_$slangcode WHERE (CONFUI_ITEM = 'DEFAULT_TAB_NAME' AND CONFUI_VALUE = TabID)), PanelID, WidgetID, WidgetOrder, WidgetParams FROM WidgetLayout WHERE AdminID='@superAdmin' AND TabID like '@HOME%'"
	fi

	if [ -f /usr/geni/customizing/WidgetLayout.sql ] ; then
		mysql -h dbserver -u root --password="$DBPASS" ALDER < /usr/geni/customizing/WidgetLayout.sql
	fi

	# Create Administrato View

	/usr/geni/centerd -A > /dev/null 2>&1

	cd /tmp
	wget -q --timeout=120 --no-check-certificate https://$ipaddr/mc/ > /dev/null 2>&1
	rm -f index.html
fi

echo " Done"

# Finish

echo ""
echo "Welcome to Genian NAC"

if [ "x$frontend" = "x1" ] ; then
	echo ""
	echo "You can connect Web Console by following URL"
	echo ""
	echo "    https://$ipaddr/mc/"
	echo ""
	echo "also you can download agent by following URL"
	echo ""
	echo "    https://$ipaddr/agent/"
elif [ "x$backend" = "x1" ] ; then
	echo "Now you can setup Frontend Server. please remember database server password"
fi
echo ""
