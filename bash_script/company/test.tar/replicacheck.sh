#/bin/bash

###
### replicastat.sh
### Execute this script on stan-by MySQL database server.
###

LOCALCONF=/disk/sys/conf/local.conf
HOST=localhost
DBUSER=`cat $LOCALCONF | grep 'data-server_username=' | awk -F'=' '{print $2}'`
if [ "x$DBUSER" == "x" ] ; then
DBUSER=root
fi
DBPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$DBPASS" == "x" ] ; then
	DBPASS=root123
fi
if [ ${#DBPASS} == 64 ] ; then
	DBPASS=`/bin/aes256 -d $DBPASS`
fi
DBPORT=`cat $LOCALCONF | grep 'data-server_port=' | awk -F'=' '{print $2}'`
if [ "x$DBPORT" == "x" ] ; then
    DBPORT=3306
fi

MHOST=
MDBPASS=$DBPASS

# For Debugging
FORCESYNC=TRUE
DEBUGMODE=PROUT
DEBUGLEVEL=SIMPLE

###
### Functions
###

function DEBUG
{
	[ "x$@" != "x" ] && logger -t `/bin/basename $0` $@
	if [ "x$DEBUGMODE" == "xPROUT" ]; then 
		echo $@
	elif [ "x$DEBUGMODE" == "xPRSYS" ]; then
		[ "x$@" != "x" ] && logger -t `/bin/basename $0` $@
	fi
}

###
### Main
###

if [ "x$HOST" == "x" ] || [ "x$DBPASS" == "x" ]; then
	DEBUG "Invalid DB Replication check configuration.";
	exit -1;
fi

## Master status

if [ "x$MHOST" == "x" ]; then
	MHOST=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Master_Host:'|awk '{print $2}'`
fi

MFILE=`mysql -u$DBUSER -h$MHOST -p$MDBPASS -P$DBPORT -E -e "show master status" 2> /dev/null|grep '^[ ]*File:'|awk '{print $2}'`
MPOS=`mysql -u$DBUSER -h$MHOST -p$MDBPASS -P$DBPORT -E -e "show master status" 2> /dev/null|grep '^[ ]*Position:'|awk '{print $2}'`

## Slave master read status

if [ "x$DEBUGLEVEL" == "xVERBOSE" ]; then
	LMFILE=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show master status" 2> /dev/null|grep '^[ ]*File:'|awk '{print $2}'`
	LMPOS=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show master status" 2> /dev/null|grep '^[ ]*Position:'|awk '{print $2}'`
fi

## Slave slave status

SFILE=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Master_Log_File:'|awk '{print $2}'`
POS=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Read_Master_Log_Pos:'|awk '{print $2}'`
EXECPOS=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Exec_Master_Log_Pos:'|awk '{print $2}'`
SQLRUN=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Slave_SQL_Running:'|awk '{print $2}'`
IORUN=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Slave_IO_Running:'|awk '{print $2}'`

if [ "x$DEBUGLEVEL" == "xVERBOSE" ]; then
	RLFILE=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Relay_Log_File:'|awk '{print $2}'`
	RLPOS=`mysql -u$DBUSER -h$HOST -p$DBPASS -P$DBPORT -E -e "show slave status" 2> /dev/null|grep '^[ ]*Relay_Log_Pos:'|awk '{print $2}'`
fi

if [ "x$MFILE" == "x" ]; then
	DEBUG "Active Database information read failed."
	exit -1;
fi

if [ "x$IORUN" != "xNo" ] && [ "x$SQLRUN" != "xNo" ]; then
	if [ "x$MFILE" != "x$SFILE" ] || [ "x$POS" != "x$EXECPOS" ]; then
		# FIXME: 현재 동기화 중인 상태인지 replication오류가 있는지 현재로서는 알수 없음.
		# IORUN/SQLRUN이 YES이더라도 동기화 동작하지 않는 경우가 있었음.
		SLAVESTATUS="MISMATCH"
	else
		SLAVESTATUS="Alived"
	fi
else
	SLAVESTATUS="Crashed"

	# Force sync
	if [ "x$FORCESYNC" == "xTRUE" ]; then
		mysql -h$HOST -u$DBUSER -p$DBPASS -P$DBPORT -e "STOP SLAVE"
		mysql -h$HOST -u$DBUSER -p$DBPASS -P$DBPORT -e "START SLAVE"
	fi
fi

# STATUS이후는 감사기록된다.

DEBUG "MFILE=$MFILE MPOS=$MPOS SFILE=$SFILE SPOS=$POS EXECPOS=$EXECPOS RLFILE=$RLFILE RLPOS=$RLPOS IORUN=$IORUN SQLRUN=$SQLRUN STATUS=$SLAVESTATUS FORCESYNC=$FORCESYNC"

