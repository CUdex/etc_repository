#!/bin/sh

if [ ! -f /disk/sys/conf/imagehash.dat ] ; then
	sha256sum /disk/sys/boot/initrd.img > /disk/sys/conf/imagehash.dat
	sha256sum /disk/sys/boot/kernel.* >> /disk/sys/conf/imagehash.dat
	sha256sum /disk/sys/boot/rootfs.* >> /disk/sys/conf/imagehash.dat
fi

HAVEFAILE=
FLIST=`cat /disk/sys/conf/imagehash.dat | awk -F' ' '{print $2}'`

for FN in $FLIST ; do
	ORGHASH=`cat /disk/sys/conf/imagehash.dat | grep $FN | awk -F' ' '{print $1}'`
	CURHASH=`sha256sum $FN | awk -F' ' '{print $1}'`

	if [ $ORGHASH != $CURHASH ] ; then
		echo $FN
		HAVEFAIL=YES
	fi
done

if [ "x$HAVEFAIL" = "x" ] ; then
	echo done
fi
