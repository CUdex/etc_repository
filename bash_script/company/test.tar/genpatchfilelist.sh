#!/bin/bash

cd /disk/data/patches && find * -type f -exec ls -l {} \; | awk '{print $9 " " $5}' > /tmp/filelist
cd /disk/data/patches && find scn2/* -type f -exec ls -l {} \; | awk '{print $9 " " $5}' >> /tmp/filelist

cd /tmp && zip filelist.zip filelist
mv filelist.zip /disk/data/patches
