#!/bin/bash

##
## Brief
##
## Last modified: 2013-10-15 13:56:26

# User Excute Binary
FIND=/usr/bin/find
GREP=/bin/grep
WGET=/bin/wget

#COLORS
CRED="[1;31m"
CGREEN="[1;32m"
CYELLOW="[1;33m"
CEND="[;m"

# Environment variable.
CMD_BRIEF="HA Syncer for distfiles."
ARG_LIST=
COMMAND=$0
ARGCNTMAX=

#####
## script configurations.
#####

LOCALCONF=/disk/sys/conf/local.conf
DISTOFFLINE=`cat $LOCALCONF | grep "^dist-offline=" | awk -F'=' '{print $2}'`
CENTERIP=`cat $LOCALCONF | grep "^interface.*ha_virtual-ip=" | awk -F'=' '{print $2}'`
HTTPSPORT=`cat $LOCALCONF | grep '^management-server_https-port=' | awk -F'=' '{print $2}'`
if [ "x$HTTPSPORT" == "x" ] ; then
	HTTPSPORT=443
fi

if [ -e /disk/sys/conf/hasyncer.conf ]; then
	CONFDIR="/disk/sys/conf"
else
	CONFDIR="/etc"
fi
LISTCONFFILE="$CONFDIR/hasyncer.conf"

cnt=0

# hasyncer.conf파일은 "PATH,URI,OPTIONS"형태
COLNUM_PATH=0
COLNUM_URI=1
COLNUM_OPTS=2

# Functions

# eg. DEBUG echo "$(date +'%F %T') File is $filename"
function DEBUG_PR
{
        [ "x$_DEBUG" == "xTRUE" ] && $@
}
_DEBUG=FALSE

function usage
{
	echo
	echo "$COMMAND is $CMD_BRIEF"
	echo ""
	echo "Use like this :"
	echo "	$COMMAND [OPTION]"
	echo ""
	echo "OPTION:"
	echo "	-h				: Show this messages."
	echo "	-c				: Clean files that does not belong to the list(_filelist.html)."
	echo "	-d				: Print debug."
	echo "	-f				: Set config file."
	echo "	-g				: Gernerate _filelist.html"
	echo "	-l				: Display list Syncer Config"
	echo "	-n				: do selected config index"
	echo "	-p				: Set specified directory only."
	echo "	-s				: Set server ip address."
	echo "	-r				: Sync or Generate according to the status of HA."
	echo
}

function clean_unnecessary() {
	FILESIZE=$(wc -c "./_filelist.html" | awk '{print $1}')
	if [ $FILESIZE -gt 0 ];then
		# make temporary needlist
		cat ./_filelist.html |awk -F\' '{print "\\<"$2"\\>"}' > ./.needfiles
		# delete unwanted from listfile
		find ./ -maxdepth 2 -type f \( ! -iname ".*" -and ! -name _filelist.html \) -print|grep -v -f ./.needfiles | awk '{print "rm -f "$1}' | sh
		# delete temporary file
		rm -f ./.needfiles
	fi
}

CMD=SYNC

while getopts hcdf:s:ln:gp:r opt
do
	case "$opt" in
		c) CMD=CLEAN;;
		d) _DEBUG=TRUE;;
		f) LISTCONFFILE=$OPTARG;;
		g) CMD=GENLIST;;
		l) CMD=LIST;;
		n) SELECTIDX=$OPTARG;;
		p) SYNCPATH=$OPTARG
			if [ "x$SYNCPATH" != "x" ]; then
				SYNCPATH=${SYNCPATH%/}
			fi
			;;
		r) CMD=CHECKHA;;
		s) CENTERIP=$OPTARG;;
		h) usage
			exit
			;;
		*) usage
			exit
			;;
	esac
done

if [ "x$_DEBUG" != "xTRUE" ]; then
	WGETOPT=-q
fi

#if [ "$#" == "0" ];then
	#usage
#	exit 1;
#fi

OLDPATH=$PWD

# Check HA status
if [ "x$CMD" == "xCHECKHA" ]; then
	HASTAT=`cat /var/run/ha*.stat|awk '{print $1}'`
	if [ "x$HASTAT" == "xSLAVE" ]; then
		CMD=SYNC
	elif [ "x$HASTAT" == "xMASTER" ]; then
		CMD=GENLIST
	else
		exit 0;
	fi
fi

if [ "x$CENTERIP" == "x" ] ; then
	echo "ERROR: node-server ip unknown"
	exit 0;
fi

while read line
do
	[ "x${line:0:1}" == "x#" ] && continue;
	[ "x${line}" == "x" ] && continue;

	hasyncconf=(${line//,/ })
	cols=${#hasyncconf[*]}

	let cnt++

	if [ "x$SYNCPATH" != "x" ]; then
		if [ "x${SYNCPATH}" == "x${hasyncconf[$COLNUM_PATH]}" ];then
			SELECTIDX=$cnt
		else
			continue;
		fi
	fi

	case "$CMD" in
	LIST)
		echo "IDX=$cnt LOCALPATH=${hasyncconf[$COLNUM_PATH]} URI=${hasyncconf[$COLNUM_URI]} OPTIONS=${hasyncconf[$COLNUM_OPTS]}"
		;;

	GENLIST)
		if [[ -n $SELECTIDX ]] && [ "x$cnt" != "x$SELECTIDX" ];then
			continue;
		fi

		cd ${hasyncconf[$COLNUM_PATH]}
		/usr/geni/tools/genfilelist.sh ${hasyncconf[$COLNUM_PATH]} &> /dev/null
		;;

	CLEAN)
		if [[ -n $SELECTIDX ]] && [ "x$cnt" != "x$SELECTIDX" ];then
			continue;
		fi

		cd ${hasyncconf[$COLNUM_PATH]}

		if [ ! -f ${hasyncconf[$COLNUM_PATH]}/_filelist.html ]; then
			continue
		fi

		clean_unnecessary

		;;

	SYNC)
		if [[ -n $SELECTIDX ]] && [ "x$cnt" != "x$SELECTIDX" ];then
			continue;
		fi

DEBUG_PR echo "## ========================================================"
DEBUG_PR echo "## PATH=${hasyncconf[$COLNUM_PATH]} NAME=${hasyncconf[$COLNUM_URI]}"
DEBUG_PR echo "## --------------------------------------------------------"

		if [ "x${hasyncconf[$COLNUM_PATH]}" == "x" ] || [ "x${hasyncconf[$COLNUM_URI]}" == "x" ]; then
			continue;
		fi

		cd ${hasyncconf[$COLNUM_PATH]}

		if [[ ${hasyncconf[COLNUM_OPTS]} == *OPT_ONLYONE* ]]; then
			# 파일 동기화
			$WGET $WGETOPT --no-check-certificate -T 30 --tries=3 -m -np -nH --cut-dirs=1 --level=2 https://${CENTERIP}:${HTTPSPORT}/${hasyncconf[$COLNUM_URI]}
		else
			# 디렉토리 동기화
			$WGET $WGETOPT --no-check-certificate -T 30 --tries=3 -m -np -nH --cut-dirs=1 --level=2 https://${CENTERIP}:${HTTPSPORT}/${hasyncconf[$COLNUM_URI]}/_filelist.html

			# 불필요한 파일 정리를 위해 _filelist.html 다운로드
			$WGET $WGETOPT --no-check-certificate -T 30 --tries=3 -np -nH --cut-dirs=1 --level=2 https://${CENTERIP}:${HTTPSPORT}/${hasyncconf[$COLNUM_URI]}/_filelist.html -O /tmp/_filelist && mv /tmp/_filelist _filelist.html
			clean_unnecessary
		fi

		DEBUG_PR echo
		;;
	esac

done < $LISTCONFFILE

cd $OLDPATH
