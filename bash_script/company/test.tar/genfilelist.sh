#!/bin/sh

if [ "x$1" = "x" ] ; then
	echo $0 [directory]
	exit 1
fi

if [ ! -d $1 ] ; then
	echo $1 is not a directory
	exit 1
fi

(cd $1; mv _filelist.html ._filelist.html; find -type f \( ! -iname ".*" \) -and ! -name ZZZ -printf "<a href='%P'>%P</a>%s<br>\n" | sed '/_filelist.html/d' |sort > _filelist.html)
(find -maxdepth 1 -type f -name ZZZ -printf "<a href='%P'>%P</a>%s<br>\n" >> _filelist.html)

DIFF=`diff $1/_filelist.html $1/._filelist.html`

if [ "x$DIFF" != "x" ] ; then
	touch $1/.changed
else
	rm -f $1/.changed
fi
