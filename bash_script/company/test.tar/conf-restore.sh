#!/bin/bash

echo '
CLI모드에서 복원이 가능합니다.
CLI모드에서 "do restore" 명령을 사용하세요.
'
exit 0

echo '

다음과 같은 순서로 RESTORE 한다.
다운그레이드를 기준으로 설명한다.
CONF 를 restore 한 이후 IP 관련 설정을 확인한다.
확인하지 않을 경우 IP 가 변경되어 접속이 불가능할수 있다.
BACKUP DB 의 버전과 다운그레이드 할 제품의 버전은 반드시 일치하여야 한다.

1. BACKUP DATA 의 압축을 푼다. 
   (BACKUP DATA 가 /disk/data/DBBACKUP 에 위치하며 파일명은 xxx.tar.gz 라고 가정한다.)
	cd /disk/data/DBBACKUP
	tar xzvf XxXxX.tar.gz

2. 아래와 같은 방법으로 다운그레이드 한다. 
	/etc/initd/alder stop
		(제품을 stop 시킨다.)
	rm -rf /disk/data/mysql/*
		(기존 DB 의 내용을 삭제한다.)
	cp -rf /disk/data/XxXxX/conf /disk/sys
		(기존 conf 를 복원한다.)
	touch /disk/sys/conf/NOSTART
		(부팅시 제품이 구동되지 않도록 한다.)
	geniup -u http://..........
	(최근버전의 경우 geniup -d -u http://.......... 와 같이 -d option 을 주어야 downgrade 가 가능하다.)
		(다운그레이드한다.)
	sync
	reboot
		(리부팅한다.)
	
3. BACKUP 된 DB 의 내용으로 restore 한다.
	/etc/init.d/mysqld start
		(DB 를 구동한다,)
	cd /disk/data/DBBACKUP/XxXxX
		(DB BACKUP 파일이 존재하는 디렉토리로 이동한다.)
	mysql -u root -p[DBPASS] ALDER < XxXxX.sql
		(DB 를 restore 한다.)
	rm -f /disk/sys/conf/NOSTART
		(다음 부팅시 제품이 구동되도록 한다.)
	sync
	reboot
	
4. 다운그레이드 완료

'
