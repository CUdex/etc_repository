#!/bin/bash

# /var/log/centerd,sensord 내에서 ALERT,CRIT 로그를 보여 준다.
CENTERLOG=/var/log/centerd
SENSORLOG=/var/log/sensord

if [ -f $CENTERLOG ] ; then
	cat $CENTERLOG | grep -E "\|ALT\||\|CRI\|"
else 
	echo "No $CENTERLOG  !!!"
fi

if [ -f $SENSORLOG ] ; then
	cat $SENSORLOG | grep -E "\|ALT\||\|CRI\|"
else 
	echo "No $SENSORLOG  !!!"
fi
