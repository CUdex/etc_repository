#!/bin/sh

# 3ware RAID write cache enable

WCACHE=`tw_cli info c0 | grep 'RAID-5' | awk '{print $8}'`

if [ "x$WCACHE" != "xRiW" ] ;then
    tw_cli set cache c0 u0 on
fi
