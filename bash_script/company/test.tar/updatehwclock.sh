#!/bin/sh
TZ=UTC hwclock --systohc
