#!/bin/bash

# function
rawurlencode() {
    local string="${1}"
    local strlen=${#string}
    local encoded=""
    local pos c o

    for (( pos=0 ; pos<strlen ; pos++ )); do
        c=${string:$pos:1}
        case "$c" in
            [-_.~a-zA-Z0-9] ) o="${c}" ;;
            * )               printf -v o '%%%02x' "'$c"
        esac
        encoded="${encoded}${o}"
    done
    echo "${encoded}"    # You can either set a return variable (FASTER)
    REPLY="${encoded}"   #+or echo the result (EASIER)... or both... :p
}
# parameter
OUTPUTFILE=""
EXTENSION="csv"
INDICES="nac*"
TYPE="NODE"
QUERYFILE=""
TIMEZONE="empty"
DELIMITER=","
QUOTATION="\""
EXPORTFIELD="all"

while [[ $# -gt 1 ]]
do
key=$1
case $key in
    -o|--output)
    OUTPUTFILE="$2"
    shift
    ;;
    -i|--indices)
    INDICES="$2"
    shift # past argument
    ;;  
    -t|--type)
    TYPE="$2"
    shift # past argument
    ;;
    -e|--extension)
    EXTENSION="$2"
    shift # past argument
    ;;
    -z|--timezone)
    TIMEZONE="$2"
    shift # past argument
    ;;
    -q|--queryfile)
    QUERYFILE=$2
    shift # past argument
    ;;
    -d|--delimiter)
    DELIMITER="$2"
    shift # past argument
    ;;
    -u|--quotation)
    QUOTATION="$2"
    shift # past argument
    ;;
    -f|--exportfield)
    EXPORTFIELD="$2"
    shift # past argument
    ;;
esac
shift # past argument or value
done

MEMSIZE=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
if [ $MEMSIZE -gt 4000000 ] ; then
    MEMOPT="-Xms3g -Xmx3g"
elif [ $MEMSIZE -gt 2000000 ] ; then
    MEMOPT="-Xms1g -Xmx1g"
else
    MEMOPT="-Xms512m -Xmx512m"
fi

if [ "x$OUTPUTFILE" == "x" ] || [ "x$QUERYFILE" == "x" ] || [ "x$INDICES" == "x" ] || [ "x$TYPE" == "x" ] ; then
    echo "Not enough parameters."
    exit 1
fi

if [ "$EXTENSION" != "csv" ] && [ "$EXTENSION" != "xls" ] && [ "$EXTENSION" != "xlsx" ] && [ "$EXTENSION" != "reidx" ] && [ "$EXTENSION" != "restore" ] ; then
    echo "Invalid output format"
    exit 1
fi

java $MEMOPT -Dfile.encoding=UTF8 -cp "/usr/tomcat/webapps.base/mc2/WEB-INF/lib/*:/usr/tomcat/shared.base/*:/usr/tomcat/lib/*" com.geninetworks.mc.es.util.ESExportUtils $EXTENSION $OUTPUTFILE $INDICES $TYPE $QUERYFILE $TIMEZONE $DELIMITER $QUOTATION $EXPORTFIELD

exit 0
