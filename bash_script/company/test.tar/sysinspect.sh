#!/bin/sh


#Made by magnus
current_day=`/bin/date +%Y%m%d`
current_time=`/bin/date +%H%M`


#automatic delete within 30day
find /disk/data/logs/sysinspect -ctime +30 -exec rm -f {} \;


# color variables
txtred2='\\e[1;31m' # Red
txtgrn2='\\e[1;32m' # Green
txtylw2='\\e[1;33m' # Yellow
txtpur2='\\e[1;35m' # Purple
txtrst='\\e[0m'    # Text Reset
txtred1='\e[1;31m' # Red
txtgrn1='\e[1;32m' # Green
txtylw1='\e[1;33m' # Yellow
txtpur1='\e[1;35m' # Purple
txtrst1='\e[0m'    # Text Reset


# major version
majorver=`cat /.version | awk -F'[-/.]' '{print $5}'`
product=`cat /.version | awk -F'[-/.]' '{print $1}'`
################################## Global Config #############################################
logdir=/disk/data/logs/sysinspect/$current_day


# SERVICE
if [ $product = 'NAC' ] || [ $product = 'GPI' ] ; then
	service_list='mysqld java centerd sensor vrrpd httpd procmond sshd syslog-ng radius'
else
	service_list='mysqld elasticsearch center gnsysd kafka tomcat vrrp httpd logstash iocdetector iocupdater snmpsrv procmon'
fi


# PRINT_SLOWQUERY
slowquery_limitsec=14


# SERVER_INFO
LOCALCONF=/disk/sys/conf/local.conf


# SHOW ERROR
error_list='CRI ERRMSG'
log_list='centerd sensord radius.log vrrpd'


# make logdir
mkdir -p $logdir
##############################################################################################
##############################################################################################
REPLACE_COMMAND(){
	sed -i 's/_/ /g' $logdir/tmp_echo
	sed -i 's/=/ /g' $logdir/tmp_echo
	cat $logdir/tmp_echo
}




SERVER_INFO() {
	echo
	echo -e "${txtylw1}=========================Server Information=========================${txtrst1}"
	echo
	# role Policy
	rolecnt=`cat /disk/sys/conf/local.conf | grep 'management-server=enable' | wc -l`
	if [ ${rolecnt} -eq 1 ] ; then
		serverrole='Policy'
	fi
	# role DB
	rolecnt=`cat /disk/sys/conf/local.conf | grep 'data-server=enable' | wc -l`
	if [ ${rolecnt} -eq 1 ] ; then
		serverrole="$serverrole DB"
	fi
	# role Logserver
	rolecnt=`cat /disk/sys/conf/local.conf | grep 'log-server=enable' | wc -l`
	if [ ${rolecnt} -eq 1 ] ; then
		serverrole="$serverrole Log"
	fi
	# check logserver port
	ES_PORT_HTTP=`cat $LOCALCONF | grep '^log-server_http-port=' | awk -F'=' '{print $2}'`
	if [ "x$ES_PORT_HTTP" == "x" ] ; then
		ES_PORT_HTTP="9200"
	fi
	# role Radius
	rolecnt=`cat /disk/sys/conf/local.conf | grep 'radius-server=enable' | wc -l`
	if [ ${rolecnt} -eq 1 ] ; then
		serverrole="$serverrole Radius"
	fi
	# role Sensor
	rolecnt1=`cat /.version | grep 'NAC-S_i686' | wc -l`
	rolecnt2=`cat /.version | grep 'NAC-SS64' | wc -l`
	if [ ${rolecnt1} -eq 1 ] || [ ${rolecnt2} -eq 1 ] ; then
		serverrole="$serverrole Sensor"
	fi
	echo -e "${txtylw1}ServerRole :$txtred1 $serverrole $txtrst1"
	echo -e "$serverrole" > $logdir/serverrole.log
	# Check HA config
	hw_groupcnt=`cat /disk/sys/conf/local.conf | grep 'interface' | grep '_ha_group' | wc -l`
	hw_prioritycnt=`cat /disk/sys/conf/local.conf | grep 'interface' | grep '_ha_priority' | wc -l`
	if [ $hw_groupcnt -ge 1 ] && [ $hw_prioritycnt -eq 1 ] ; then
		if [ $majorver -eq 4 ] ; then
			echo -e "${txtylw1}H/W duplexing : ${txtgrn1}Enable / ${txtgrn1}`cat /var/run/ha_*`${txtrst1}"
			ha_status=`cat /var/run/ha_* | awk '{print $1}'`
		fi
		if [ $majorver -eq 5 ] ; then
			echo -e "${txtylw1}H/W duplexing : ${txtgrn1}Enable / ${txtgrn1}`cat /var/run/ha_* | grep Status | awk -F ': ' '{print $2}'`${txtrst1}"
			ha_status=`cat /var/run/ha_* | grep Status | awk -F ': ' '{print $2}'`
		fi
	else
		echo -e "${txtylw1}H/W duplexing : ${txtred1}Disabled${txtrst1}"
	fi
	# check_DB_Replication
	dbcnt=`grep DB $logdir/serverrole.log | wc -l`
	if [ $dbcnt -eq 1 ] ; then
		if [ $hw_groupcnt -eq 1 ] && [ $hw_prioritycnt -eq 1 ] ; then
			echo -e "${txtylw1}DB replication : ${txtgrn1}Enable${txtrst1}"
		else
			echo -e "${txtylw1}DB replication : ${txtred1}Disabled${txtrst1}"
		fi
	fi
	DBUSER=`cat $LOCALCONF | grep 'data-server_username=' | awk -F'=' '{print $2}'`
	ori_DBPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
	if [ ${#ori_DBPASS} == 64 ] ; then
		DBPASS=`/bin/aes256 -d $ori_DBPASS`
	fi
	# Check DB replication MASTER
	if [ $hw_groupcnt -eq 1 ] && [ $hw_prioritycnt -eq 1 ] && [ $dbcnt -eq 1 ] && [ $ha_status = 'MASTER' ] ; then
		mysql -u$DBUSER -p$DBPASS -e 'show processlist' > processlist
		slave_ip=`cat ./processlist | grep 'Binlog Dump' | awk '{print $3}' | awk -F ':' '{print $1}'`


		# find out repicationg file name
		master_file=`mysql -u$DBUSER -p$DBPASS -E -e "show master status" | grep File | awk '{print $2}'`
		slave_file=`mysql -h$slave_ip -u$DBUSER -p$DBPASS -E -e 'show slave status \G' | grep Relay_Master_Log_File | awk '{print $2}'`

		# find out replication position
		master_position=`mysql -u$DBUSER -p$DBPASS -E -e "show master status" | grep Position | awk '{print $2}'`
		slave_position=`mysql -h$slave_ip -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Read_Master_Log_Pos | awk '{print $2}'`



		# Check slave_DB IO RUN
		slave_iorun=`mysql -h$slave_ip -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Slave_IO_Running | awk '{print $2}'`
		slave_sqlrun=`mysql -h$slave_ip -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Slave_SQL_Running: | awk '{print $2}'`
		if [ $master_file = $slave_file ] && [ $master_position = $slave_position ] ; then
			echo -e "${txtgrn1}STATUS=ALIVE$txtrst1 MFILE=$master_file SFILE=$slave_file MPOS=$master_position SPOS=$slave_position IORUN=$slave_iorun SQLRUN=$slave_sqlrun"
		else
			echo -e "${txtred1}STATUS=MISSMATCH${txtrst1} MFILE=$master_file SFILE=$slave_file MPOS=$master_position SPOS=$slave_position IORUN=$slave_iorun SQLRUN=$slave_sqlrun"
		fi
	fi
	# Check DB replication SLAVE
	if [ $hw_groupcnt -eq 1 ] && [ $hw_prioritycnt -eq 1 ] && [ $dbcnt -eq 1 ] && [ $ha_status = 'SLAVE' ] ; then
		master_ip=`cat /disk/sys/conf/local.conf | grep data-server_replica_masterhost= | awk -F '=' '{print $2}'`


		# find out repicationg file name
		master_file=`mysql -h$master_ip -u$DBUSER -p$DBPASS -E -e "show master status" | grep File | awk '{print $2}'`
		slave_file=`mysql -u$DBUSER -p$DBPASS -E -e 'show slave status \G' | grep Relay_Master_Log_File | awk '{print $2}'`


		# find out replication position
		master_position=`mysql -h$master_ip -u$DBUSER -p$DBPASS -E -e "show master status" | grep Position | awk '{print $2}'`
		slave_position=`mysql -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Read_Master_Log_Pos | awk '{print $2}'`


		# Check slave_DB IO RUN
		slave_iorun=`mysql -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Slave_IO_Running | awk '{print $2}'`
		slave_sqlrun=`mysql -u$DBUSER -p$DBPASS -E -e 'show slave status \G'| grep Slave_SQL_Running: | awk '{print $2}'`
		if [ $master_file = $slave_file ] && [ $master_position = $slave_position ] ; then
			echo -e "${txtgrn1}STATUS=ALVIVE${txtrst1} MFILE=$master_file SFILE=$slave_file MPOS=$master_position SPOS=$slave_position IORUN=$slave_iorun SQLRUN=$slave_sqlrun"
		else
			echo -e "${txtred1}STATUS=MISSMATCH${txtrst1} MFILE=$master_file SFILE=$slave_file MPOS=$master_position SPOS=$slave_position IORUN=$slave_iorun SQLRUN=$slave_sqlrun"
		fi
	fi


	# uptime, platform, version..
	uptimeinfo=`uptime`
	echo "System Uptime : $uptimeinfo"
	if [ $majorver -lt 5 ] ; then
		platform=`cat /var/etc/PLATFORM`
	else
		platform=`cat /var/geni/etc/PLATFORM`
	fi
	echo "Platform : $platform"
	version=`cat /.version`
	echo "Version : $version"
	echo -e "MAC Address List"




	ethcnt=`ifconfig | grep eth | awk '{print $1}'`
	for eths in $ethcnt;do
		ethmac=`ethtool -P $eths | awk '{print $3}'`
		echo "$eths MAC Address : $ethmac"
	done
	echo
	echo -e "${txtylw1}=========================Service Version=========================${txtrst1}"
	opensslver=`openssl version | awk '{print $2,$3,$4,$5}'`
	echo -e "OpenSSL Version : $opensslver"
	sensorcnt=`grep Sensor $logdir/serverrole.log | wc -l`
	if [ $sensorcnt -ne 1 ] ; then #if server is not sensor
		mysqlver=`mysql --version | awk '{print $3,$4 ,$5, $7,$8}'`
		echo -e "MySQL Version : $mysqlver"
		apachever=`/usr/tomcat/bin/version.sh | grep 'Server number' | awk '{print $3}'`
		echo -e "Apache Version : $apachever"
		javaver=`java -version 2>&1 | grep 'java version\|openjdk version' | awk '{print $3}' | sed -e "s/\"//g"`
		echo -e "Java Version : $javaver"


		if [ $product != 'GPI' ] ; then
			logservercnt=`grep Log $logdir/serverrole.log | wc -l`


			if [ $logservercnt -eq 1 ] ; then
				elasticver=`curl -XGET "localhost:${ES_PORT_HTTP}" 2>&1 > $logdir/elasticsearch_ver.log`
				sed -i "s/\"//g" $logdir/elasticsearch_ver.log
				sed -i "s/\,//g" $logdir/elasticsearch_ver.log
				elasticver=`cat $logdir/elasticsearch_ver.log | grep number | awk '{print $3}'`
				echo -e "ElasticSearch Version : $elasticver"

			fi
		fi
	fi
	##############################################################################################
	if [ $product != 'GPI' ] ; then
		logservercnt=`grep Log $logdir/serverrole.log | wc -l`
		if [ $logservercnt -eq 1 ] ; then
			echo -e "${txtylw1}=========================elasticsearch indices Health check========================= $txtrst1"
			check_elastic=`curl "logserver:${ES_PORT_HTTP}/_cat/indices?v" 2>&1  > $logdir/elasticsearch.log`
			sed -i "s/yellow/${txtylw2}yellow${txtrst}/g" $logdir/elasticsearch.log
			sed -i "s/red/${txtred2}red${txtrst}/g" $logdir/elasticsearch.log
			sed -i "s/green/${txtgrn2}green${txtrst}/g" $logdir/elasticsearch.log
			awk '{sub(/0/,"\e[1;31m0\e[0m",$5);print > "'$logdir'/elasticsearch1.log"}' $logdir/elasticsearch.log
			FILE_PRINT elasticsearch1.log
		fi
	fi
	##############################################################################################
	logcnt=`grep Log $logdir/serverrole.log | wc -l`
	if [ $logcnt -eq 1 ] ; then
		backupcnt=`ls /disk/data/LOGBACKUP/ | grep $current_day | wc -l`
		if [ $backupcnt -ge 2 ] ; then
			backupstatus='${txtgrn1}OK${txtrst1}'
			echo -e "${txtylw1}=========================Last 7 days Log Backup Check(${txtgrn1}Today OK${txtrst1}${txtylw1})=========================${txtrst1}"
			ls -ltr /disk/data/LOGBACKUP/ | grep -v ^d | grep -v index | tail -n 14
		else
			echo -e "${txtylw1}=========================Last 7 days Log Backup Check(${txtred1}Today Warning${txtred1}${txtylw1})=========================${txtrst1}"
			ls -ltr /disk/data/LOGBACKUP/ | grep -v ^d | grep -v index | tail -n 14
		fi
	fi
	##############################################################################################
	logcnt=`grep Policy $logdir/serverrole.log | wc -l`
	if [ $logcnt -eq 1 ] ; then
		backupcnt=`ls /disk/data/DBBACKUP/ | grep $current_day | wc -l`
		if [ $backupcnt -ge 1 ] ; then
			backupstatus='${txtgrn1}OK${txtrst1}'
			echo -e "${txtylw1}=========================Last 7 days DB Backup Check(${txtgrn1}Today OK${txtrst1}${txtylw1})=========================${txtrst1}"
			ls -ltr /disk/data/DBBACKUP/ | grep -v ^d | tail -n 7
		else
			echo -e "${txtylw1}=========================Last 7 days DB Backup Check(${txtred1}Today Warning${txtred1}${txtylw1})=========================${txtrst1}"
			ls -ltr /disk/data/DBBACKUP/ | grep -v ^d | tail -n 7
		fi
	fi
}
##############################################################################################
##############################################################################################
FILE_PRINT() {
	linecnt=`cat $logdir/$1 | wc -l`
	for ((i=1 ; i <=$linecnt ; i++)); do
		print=`head -n $i $logdir/$1 | tail -n1`
		echo -e "$print"
	done
}
##############################################################################################
##############################################################################################
SERVICE() {
	echo
	echo -e "${txtylw1}=========================Check service status=========================${txtrst1}"
	echo
	rm -rf $logdir/ps.log
	for service in $service_list; do
		servicecnt=`ps -ef | grep $service | grep -v  grep | wc -l`
		if [ $service = 'httpd' ] ; then
			echo -e "################# $service($servicecnt) $txtrst1############################" >> /$logdir/ps.log
		else
			echo -e "################# $service $txtrst1############################" >> /$logdir/ps.log
		fi
		ps -eo pid,spid,ppid,stat,user,c,pmem,sz,vsz,rss,tname,lstart,time,cmd | egrep "PID|$service" | grep -v egrep >> $logdir/ps.log
		echo "\n" >> $logdir/ps.log
		sed -i "s/$service/\\\\e\[1\;31m$service \\\\e\[0m/g" $logdir/ps.log
	done
	FILE_PRINT ps.log
}
##############################################################################################
##############################################################################################
DISKINFO() {
	disk_attach=`df -k | grep data | wc -l`
	if [ $disk_attach -ge 1 ] ; then
		echo
		echo -e "${txtylw1}=========================Check disk information=========================${txtrst1}"
		diskinfo
		echo


		#logdir=/disk/data/script/df.log
		df -k > $logdir/df.log
		total_ori=`grep "/disk/data$" $logdir/df.log  | awk '{print $2}'`
		total_modi=`echo "$total_ori" | awk '{printf "%.2f", $1 / 1024}'`
		total_compare=`expr $total_ori / 1024`
		used_ori=`grep "/disk/data$" $logdir/df.log  | awk '{print $3}'`
		used_modi=`echo "$used_ori" | awk '{printf "%.2f", $1 / 1024}'`
		used_compare=`expr $used_ori / 1024`
		avail_ori=`grep "/disk/data$" $logdir/df.log  | awk '{print $4}'`
		avail_modi=`echo "$avail_ori" | awk '{printf "%.2f", $1 / 1024}'`
		avail_compare=`expr $avail_ori / 1024`


		# classify MB/GB
		for list in total used avail; do
			result=$(eval echo \$${list}_modi)
			result_compare=$(eval echo \$${list}_compare)
			if [ $result_compare -ge 1024 ] ; then
				temp=`echo "$result" | awk '{printf "%.2f", $1 / 1024}'`
				declare ${list}_modi=$temp'GB'
			else
				temp=$result
				declare ${list}_modi=$temp'MB'
			fi
		done
		sed -i "s/$total_ori/$txtylw2 $total_modi $txtrst/g" $logdir/df.log
		sed -i "s/$used_ori/$txtred2 $used_modi  $txtrst/g" $logdir/df.log
		sed -i "s/$avail_ori/$txtgrn2 $avail_modi $txtrst/g" $logdir/df.log
		if [ `df -k | grep ssdev | wc -l` -eq 1 ] ; then
			total_ssd_ori=`grep "ssdev" $logdir/df.log  | awk '{print $2}'`
			total_ssd_modi=`echo "$total_ssd_ori" | awk '{printf "%.2f", $1 / 1024}'`
			total_ssd_compare=`expr $total_ssd_ori / 1024`
			used_ssd_ori=`grep "ssdev" $logdir/df.log  | awk '{print $3}'`
			used_ssd_modi=`echo "$used_ssd_ori" | awk '{printf "%.2f", $1 / 1024}'`
			used_ssd_compare=`expr $used_ssd_ori / 1024`
			avail_ssd_ori=`grep "ssdev" $logdir/df.log  | awk '{print $4}'`
			avail_ssd_modi=`echo "$avail_ssd_ori" | awk '{printf "%.2f", $1 / 1024}'`
			avail_ssd_compare=`expr $avail_ssd_ori / 1024`

			# classify MB/GB
			for list in total_ssd used_ssd avail_ssd; do
				result=$(eval echo \$${list}_modi)
				result_compare=$(eval echo \$${list}_compare)

				if [ $result_compare -ge 1024 ] ; then
					temp=`echo "$result" | awk '{printf "%.2f", $1 / 1024}'`
					declare ${list}_modi=$temp'GB'
				else
					temp=$result
					declare ${list}_modi=$temp'MB'
				fi
			done


			sed -i "s/$total_ssd_ori/$txtylw2 $total_ssd_modi $txtrst/g" $logdir/df.log
			sed -i "s/$used_ssd_ori/$txtred2 $used_ssd_modi  $txtrst/g" $logdir/df.log
			sed -i "s/$avail_ssd_ori/$txtgrn2 $avail_ssd_modi $txtrst/g" $logdir/df.log
		fi
		FILE_PRINT df.log
	else
		echo -e "${txtred1} Error!! HardDisk Detached! check Hard disk status ${txtrst1}"
	fi


	###check SSD attach
	if [ $majorver -lt 5 ] ; then
		platform=`cat /var/etc/PLATFORM`
	else
		platform=`cat /var/geni/etc/PLATFORM`
	fi


	ssd_lists="C40 C50 ES30 ES50 C10_R1 C20_R1 C30_R1 C40_R1 C50_R1"
	check_cnt=0


	for ssd in $ssd_lists;do
		if  [ $platform = $ssd ] ; then
			((check_cnt++))
		fi
	done
	if [ $check_cnt -eq 2 ] ; then
		if [ `df -k | grep ssdev | wc -l` -ne 1 ] ; then
			echo -e "${txtred1}Error!! SSD Detached! check Hard disk status ${txtrst1}"
		fi
	fi
}
##############################################################################################
##############################################################################################
SMARTCTL() {
	echo
	echo -e "${txtylw1}=========================Check smartctl=========================${txtrst1}"
	echo
	#logdir=/disk/data/script/smartctl.log
	target=`df -k | grep '/disk/data$' | awk '{print $1}'`
	smartctl -a $target > $logdir/smartctl.log
	for list in Reallocated_Sector_Ct Current_Pending_Sector Offline_Uncorrectable UDMA_CRC_Error_Count; do
		target_word=`cat $logdir/smartctl.log | grep $list`
		sed -i "s/$target_word/$txtylw2$target_word $txtrst/g" $logdir/smartctl.log
	done
	FILE_PRINT smartctl.log
}
##############################################################################################
##############################################################################################
FREE() {
	echo
	echo -e "${txtylw1}=========================Check memory information=========================${txtrst1}"
	echo
	free
	total=`free | grep Mem | awk '{print $2}'`
	used=`free | grep Mem | awk '{print $3}'`
	per=`echo "$used $total" | awk '{printf "%.2f", $1 / $2 * 100}'`
	echo -e "Use% : $per% \n"
	memtotal=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
	memfree=`cat /proc/meminfo | grep MemFree | awk '{print $2}'`
	membuff=`cat /proc/meminfo | grep Buffers | awk '{print $2}'`
	memcashed=`cat /proc/meminfo | grep "^Cached" | awk '{print $2}'`
	memusage=`free | grep Mem | awk '{print $3}'`


	memper=`echo $memtotal $memfree $membuff $memcashed | awk '{printf "%.2f", ($1 - $2 - $3 - $4) * 100 / $1 }'`
	calmemtotal=`echo "$memtotal" | awk '{printf "%.2f", $1 / 1024 /1024}'`
	calmemfree=`echo "$memfree" | awk '{printf "%.2f", $1 / 1024 /1024}'`
	calmemusage=`echo "$memusage" | awk '{printf "%.2f", $1 / 1024 /1024}'`
	echo -e "${txtylw1}Actual usage(Web): $memper % ${txtrst1}"
	echo -e "total memory : ${txtylw1}${calmemtotal} GB${txtrst1}"
	echo -e "usage memory : ${txtred1}${calmemusage} GB${txtrst1}"
	echo -e "free memory  : ${txtgrn1}${calmemfree} GB${txtrst1}"
	echo "* Formula usage = (total - (free + buff + cashed) / 100 "
	#echo -e "${txtylw1}If you want to cleanup momory excute command${txtrst1}"
	#echo -e "${txtylw1}echo 3 > /proc/sys/vm/drop_caches${txtrst1}"
}
##############################################################################################
##############################################################################################
TOTAL() {
	SERVER_INFO
	SERVICE
	DISKINFO
	FREE
	SMARTCTL
}
##############################################################################################
##############################################################################################
PRINT_SLOWQUERY() {
	slowquerylog=/disk/data/logs/mysqld/slowquery.log
	if [ `ls $slowquerylog 2> /dev/null | wc -l` -eq 1 ] ; then
		linecnt=`cat $slowquerylog | wc -l`
		rm -rf $logdir/slowquery.log
		echo
		echo -e "${txtylw1}=========================DB Slow Query(Limit Sec : $slowquery_limitsec) List=========================${txtrst1}"
		echo
		for ((i=1 ; i <=$linecnt ; i++)); do
			querycnt=`head -n $i $slowquerylog | tail -n1 | grep 'Query_time' | wc -l`
			if [ $querycnt -eq 1 ] ; then
				querytime=`head -n $i $slowquerylog | tail -n1 | grep 'Query_time' | awk '{print $3}'`
				int_querytime=`echo "$querytime" | awk '{printf "%d", $1 }'`
				if [ "$int_querytime" -gt "$slowquery_limitsec" ] ; then
					echo -e "${txtred1}This is very Slow Query  querytime = $querytime $txtrst1" >> $logdir/slowquery.log
					cutlinecompare=`grep -B 3 -A 4 $querytime $slowquerylog | tail -n1 | awk '{print $2}'`
					cutline=`grep -B 3 -A 4 $querytime $slowquerylog | tail -n1 | awk '{print $4}'`
					if [ $cutlinecompare = 'Time:' ] ; then    ###clear last line
						grep -B 3 -A 4 $querytime $slowquerylog | grep -v "$cutline" >> $logdir/slowquery.log
					else
						grep -B 3 -A 4 $querytime $slowquerylog >> $logdir/slowquery.log
					fi
				fi
			fi
		done
		if [ `ls cat $logdir/slowquery.log 2>/dev/null | wc -l` -eq 1 ] ; then
			cat $logdir/slowquery.log | more
		else
			echo -e "${txtgrn1}Slowquery does not exist!!$txtrst1"
		fi
	fi
	echo
}
##############################################################################################
##############################################################################################
SHOW_ERR() {
	dblogcnt=`ls /disk/data/logs/mysqld/mysqld.error | wc -l`
	for logname in $log_list;do
		log_exist=`ls /disk/data/logs/system/| grep $logname | wc -l`
		if [ $log_exist -eq 1 ] ; then
			echo -e "\n${txtgrn1}############### $logname ###############$txtrst1"
			for error in $error_list;do
				echo -e "${txtylw1}######## $error ###########$txtrst1"
				cat /disk/data/logs/system/$logname | grep $error | tail -n30
			done
		fi
	done
	if [ $dblogcnt -eq 1 ] ; then
		echo -e "${txtylw1}############### myqld.error ###############$txtrst1"
		cat /disk/data/logs/mysqld/mysqld.error | tail -n30
	fi
}
##############################################################################################
CEHCK_CONFIG_SETUP(){


	#call serverinfo
	SERVER_INFO > /dev/null


	indexnum=1


	echo -e "\n\n${txtpur1}######## SETUP Config Check ###########$txtrst1"
	##debug config check
	sensorcnt=`grep Sensor $logdir/serverrole.log | wc -l`
	if [ $sensorcnt -ne 1 ] ; then  ### if Policy DB LOG....
		debugcnt=`cat $LOCALCONF | grep "debug_centerd" | wc -l`
		if [ $debugcnt -eq 0 ] || [ $debugcnt -lt 2  ] ; then
			echo -e "${txtylw1}${indexnum}. Warning debug centerd configs are not enough settings!!${txtrst1}"
			echo -e "${txtylw1}CLI Command : debug centerd all${txtrst1}\n"
		else
			echo -e "${txtgrn1}${indexnum}. debug centerd configs enable OK!${txtrst1}"
		fi
	else ###if Sensor....
		nohdd_sensor_list="GNS-100-T01 GNS-100-T20 NS-100-T20_R1 GNS-200-T02 GNS-700-T03 GNS-800-T40 GNS-800-T40A GNS-900-T40 S10 S10_R1 S20 S20-E S20_R1 S20_R1-E"
		if [ $majorver -lt 5 ] ; then
			platform=`cat /var/etc/PLATFORM`
		else
			platform=`cat /var/geni/etc/PLATFORM`
		fi


		##check no HDD Sensor
		check_cnt=0
		for no_sensor in $nohdd_sensor_list;do
			if [ $platform = $no_sensor ] ; then
				((check_cnt++))
			fi
		done


		debugcnt=`cat $LOCALCONF | grep "debug_sensord" | wc -l`
		if [ $check_cnt -eq 0 ] ; then
			if [ $debugcnt -eq 0 ] || [ $debugcnt -lt 2  ] ; then
				echo -e "${txtylw1}${indexnum}. Warning debug sensord configs are not enough settings!!${txtrst1}"
				echo -e "${txtylw1}CLI Command : debug sensord all${txtrst1}\n"
			else
				echo -e "${txtgrn1}${indexnum}. debug sensord configs enable OK!${txtrst1}"
			fi
		fi
	fi


	## increase print indexnum
	((indexnum++))
	debugcnt=`cat $LOCALCONF | grep "debug_vrrpd" | wc -l`


	if [ $hw_groupcnt -ge 1 ] && [ $hw_groupcnt -lt 2 ] ; then
		echo -e "${txtylw1}${indexnum}. Warning debug centerd configs are not enough settings!!${txtrst1}"
		echo -e "${txtylw1}CLI Command : debug vrrpd all${txtrst1}\n"


		## increase print indexnum
		((indexnum++))
	fi




	## HA config check
	if [ $hw_groupcnt -ge 1 ] ; then
		if [ $sensorcnt -eq 0 ] ; then ##sensor
			halists="linkupdelay nopreempt priority timeout virtual-ip"
		else
			halists="linkupdelay nopreempt priority timeout"
		fi


		echo -e "${txtylw1}${indexnum}. HA config check ${txtrst1}"
		for i in $halists;do
			cnt=`cat $LOCALCONF | grep $i | wc -l`
			if [ $cnt -ne 1 ] ; then
				echo -e "${txtred1}You must do HA $i config!!${txtrst1}"
			else
				echo -e "${txtgrn1}HA $i config enable OK!${txtrst1}"
				if [ $i = virtual-ip ] ; then
					echo "`cat $LOCALCONF | grep virtual-ip`" > $logdir/tmp_echo
					REPLACE_COMMAND
				fi
			fi
		done
		echo -e ""
		## increase print indexnum
		((indexnum++))
	fi


	## DB config check
	aclcnt=`cat $LOCALCONF | grep 'access-list' | wc -l`
	dbcnt=`grep DB $logdir/serverrole.log | wc -l`
	if [ $dbcnt -eq 1 ] ; then
		## check DB acl config
		if [ $aclcnt -eq 1 ] ; then
			echo -e "${txtgrn1}${indexnum}. DB ACL config enable OK!${txtrst1}"
			echo -e "`cat $LOCALCONF | grep 'access-list'`\n" > $logdir/tmp_echo
			REPLACE_COMMAND
		else
			echo -e "${txtred1}${indexnum}. You must do DB ACL configs!!${txtrst1}"
			echo -e "${txtylw1}CLI Command : data-server access-list [IP]${txtrst1} \n"
		fi


		## increase print indexnum
		((indexnum++))


		## check DB Replication config(DBserver && HA enalbe)
		if [ $dbcnt -eq 1 ] && [ $hw_groupcnt -eq 1 ] ; then
			if [ `cat $LOCALCONF | grep serverid | wc -l` -eq 0 ] ; then
				echo -e "${txtred1}${indexnum}. You must do DB replica materhost config${txtrst1}"
				echo -e "${txtylw1}CLI Command : data-server replica masterhost [IP]${txtrst1} \n"
			else
				echo -e "${txtgrn1}${indexnum}. DB Replica serverid config enable OK!${txtrst1}\n"
			fi


			## increase print indexnum
			((indexnum++))




			if [ $ha_status = 'SLAVE' ] ; then
				if [ `cat $LOCALCONF | grep masterhost | wc -l` -eq 0 ] ; then
					echo -e "${txtred1}${indexnum}. You must do DB replication materhost config${txtrst1}"
					echo -e "${txtylw1}CLI Command : data-server replica masterhost [IP]${txtrst1}"
				else
					echo -e "${txtgrn1}${indexnum}. DB Replication config enable OK!${txtrst1}"
					echo -e "`cat $LOCALCONF | grep masterhost`\n" > $logdir/tmp_echo
					REPLACE_COMMAND

				fi


				## increase print indexnum
				((indexnum++))
			fi
		fi
	fi


	##Elasticsearch cluster config check
	if [ `grep Log $logdir/serverrole.log | wc -l` -eq 1 ] && [ $hw_groupcnt -ge 1 ] ; then
		if [ `cat $LOCALCONF | grep cluster-peers | wc -l` -eq 0 ] ; then
			echo -e "${txtred1}${indexnum}. You must do cluster-peers config${txtrst1}"
			echo -e "${txtylw1}CLI Command : log-server cluster-peers [Policy IP],[Log IP]${txtrst1}\n"
		else
			echo -e "${txtgrn1}${indexnum}. Log Cluster IP config enable OK!${txtrst1}"
			echo -e "`cat $LOCALCONF | grep cluster-peers`\n" > $logdir/tmp_echo
			REPLACE_COMMAND
		fi


		## increase print indexnum
		((indexnum++))
	fi


	##sensor HA config check
	##check nodeserver connection
	#######if exclude Policy, excute under function
	if [ `cat $logdir/serverrole.log | grep 'Policy' | wc -l` -eq 0 ] ; then
		if [ `cat $LOCALCONF | grep device-id | wc -l` -eq 0 ] || [ `cat $LOCALCONF | grep 'node-server_ip' | wc -l` -eq 0 ] ; then
			echo -e "${txtred1}${indexnum}. You must do nodeserver ip config and check Connection"
			echo -e "${txtylw1}CLI Command : node-server ip [ip]${txtrst1}"
		else
			echo -e "${txtgrn1}${indexnum}. nodeserver IP config & connection OK!${txtrst1}"
			echo -e "`cat $LOCALCONF | grep 'node-server_ip'`\n" > $logdir/tmp_echo
			REPLACE_COMMAND
		fi
	fi


	echo -e "\n\n${txtpur1}#######################################$txtrst1"
}
##############################################################################################


if [ "$0" != "///disk/data/new/sysinspect.sh" ] ; then
	echo "Checking for update..."
	if [ ! -d /disk/data/new ] ; then
		mkdir -p /disk/data/new
	fi
	cd /disk/data/new
	wget --no-check-certificate -N --timeout=5 --tries=3 https://download.geninetworks.com/NAC/sysinspect.sh &> /dev/null
	if [ -f sysinspect.sh ] ; then
		chmod 755 ./sysinspect.sh
		DIFF=`diff /usr/geni/tools/sysinspect.sh ./sysinspect.sh`


		if [ "x$DIFF" != "x" ] ; then
			echo Execute from /disk/data/new/sysinspect.sh
			echo ''
			///disk/data/new/sysinspect.sh $1
			exit
		fi
	fi
	echo Updated version not found
	echo ''
fi


##############################################################################################
clear
echo -e "${txtylw1}==========Regualr Inspection==========${txtrst1}"
echo -e "${txtgrn1} 1) Check Server/Service infomation"
echo -e "${txtgrn1} 2) Check Service status"
echo -e "${txtgrn1} 3) Check Disk & Memory information"
echo -e "${txtgrn1} 4) Check Smartctl"
echo -e "${txtgrn1} 5) Check Slow Query"
echo -e "${txtgrn1} 6) Check Total Inspection"
echo -e "${txtgrn1} 9) Check Setup Config"
echo -e "${txtylw1}======================================${txtrst1}"
echo -n "Enter Select Number : "
read answer
case "$answer" in
	1)
		SERVER_INFO
		;;
	2)
		SERVICE
		;;
	3)
		DISKINFO
		FREE
		;;
	4)
		SMARTCTL
		;;
	5)
		# this funtion only operate in DB server
		dbcnt=`grep DB $logdir/serverrole.log | wc -l`
		if [ $dbcnt -eq 1 ] ; then
			PRINT_SLOWQUERY
		else
			echo -e "\n${txtred1}This is not DB Server $txtrst1"
		fi
		;;
	6)
		TOTAL
		;;
	9)
		CEHCK_CONFIG_SETUP
		;;
	0)
		SHOW_ERR
		;;
	*)
		echo "wrong answer."
		;;
esac
###############################################################################
