#/bin/bash

###
### MySQL Replication table checksum verifier.
### 	Please run on slave db.
###
### LASTMODIFIED: 2016-05-17 13:27:50

#_DEBUGTYPE="SYSTEMLOG"
_DEBUGTYPE="STDOUT"
LOCALCONF=/disk/sys/conf/local.conf
COMMAND=`/bin/basename $0`

function usage
{
	echo
	echo
	echo "$COMMAND is ${CMD_BRIEF}."
	echo ""
	echo "Use like this :"
	echo "  $COMMAND [OPTION] [TableName]"
	echo ""
	echo "OPTION:"
	echo "  -h               : Show this messages."
	echo "  --dosync          : Do synchronize in interacitve mode"
	#echo "  --forceall       : Do synchronize forcefully in non-interacitve mode"
	echo
	echo "
	HOW TO USE:
	$ $0
	"
}

### Parameter

DOSYNC=FALSE

while getopts :h-: opt
do
	case "$opt" in
		h)
			usage
			exit;;
		-) 
			case "$OPTARG" in
				dosync) DOSYNC=TRUE;;
				forceall) FORCEALL=TRUE;;
				*)
					if [ "$OPTERR" = 1 ] && [ "${optspec:0:1}" != ":" ]; then
						echo "Unknown option --${OPTARG}" >&2
					fi
					usage
					exit
					;;
			esac
			;;
		*)
			if [ "$OPTERR" = 1 ] && [ "${optspec:0:1}" != ":" ]; then
				echo "Unknown option -${OPTARG}" >&2
			fi
			usage
			exit;;
	esac
done

TABLES=${!OPTIND}
pid_centerd=$(pidof centerd)

function PRSTDOUT
{
	if [ "x$@" != "x" ]; then
		echo "$COMMAND: $@"
	else
		echo
	fi
}

function DEBUG
{
	[ "x$@" != "x" ] && logger -t $COMMAND $@
	if [ "x$_DEBUGTYPE" == "xSTDOUT" ]; then 
		echo $@
	fi
}

function DEBUGV
{
	if [ "x$_DEBUGTYPE" == "xSTDOUT" ]; then 
		echo $@
	elif [ "x$_DEBUGTYPE" == "xSYSTEMLOG" ]; then 
		[ "x$@" != "x" ] && logger -t $COMMAND $@
	fi
}

function forcesync()
{
	tab=$1
	DEBUG "Synchronize forcefully. TABLE=${tab} OLDROWS=${STABROWS} NEWROWS=${MTABROWS}"
	if [ "x$pid_centerd" != "x" ]; then
		DEBUG "ERROR: Failed to synchronize. REASON='centerd process is running'"
		exit
	else
		mysqldump -f -h$MASTERHOST -u$MASTERDBUSER -p$MASTERDBPASS $MASTERDBNAME $tab > /tmp/${tab}.sql
		mysql -h$SLAVEHOST -u$SLAVEDBUSER -p$SLAVEDBPASS $SLAVEDBNAME < /tmp/${tab}.sql
		rm -f /tmp/${tab}.sql
	fi
}

# Read Slave Configurations

SLAVEHOST=dbserver
SLAVEDBNAME=ALDER
SLAVEDBUSER=`cat $LOCALCONF | grep 'data-server_username=' | awk -F'=' '{print $2}'`
if [ "x$SLAVEDBUSER" == "x" ]; then
	SLAVEDBUSER=root
fi
SLAVEDBPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$SLAVEDBPASS" == "x" ] ; then
	SLAVEDBPASS=root123
fi
if [ ${#SLAVEDBPASS} == 64 ] ; then
	SLAVEDBPASS=`/bin/aes256 -d $SLAVEDBPASS`
fi

# Read Master Configurations

MASTERDBUSER=`cat $LOCALCONF | grep '^data-server_replica_username=' | awk -F'=' '{print $2}'`
if [ "x$MASTERDBUSER" == "x" ] ; then
	MASTERDBUSER=root
fi
MASTERDBPASS=`cat $LOCALCONF | grep '^data-server_replica_password=' | awk -F'=' '{print $2}'`
if [ "x$MASTERDBPASS" == "x" ] ; then
	MASTERDBPASS=root123
fi
if [ ${#MASTERDBPASS} == 64 ] ; then
	MASTERDBPASS=`/bin/aes256 -d $MASTERDBPASS`
fi
#MASTERDBNAME=`cat $LOCALCONF | grep '^data-server_replica_dbname=' | awk -F'=' '{print $2}'`
MASTERDBNAME=$SLAVEDBNAME
MASTERHOST=`cat $LOCALCONF | grep '^data-server_replica_master=' | awk -F'=' '{print $2}'`


if [ "x$SLAVEHOST" == "x" ] || [ "x$SLAVEDBPASS" == "x" ]; then
	DEBUG "ERROR: Invalid DB Replication configuration. ('data-server')";
	exit -1;
fi

###
### Read master info.
###

[ "x$MASTERHOST" == "x" ] && MASTERHOST=`mysql -u$SLAVEDBUSER -h$SLAVEHOST -p$SLAVEDBPASS -E -e "show slave status" 2> /dev/null|grep '[^_]Master_Host'|awk '{print $2}'`
[ "x$MASTERDBUSER" == "x" ] && MASTERDBUSER=`mysql -u$SLAVEDBUSER -h$SLAVEHOST -p$SLAVEDBPASS -E -e "show slave status" 2> /dev/null|grep '[^_]Master_User'|awk '{print $2}'`
[ "x$MASTERDBPASS" == "x" ] && MASTERDBPASS=$SLAVEDBPASS
[ "x$MASTERDBNAME" == "x" ] && MASTERDBNAME=$SLAVEDBNAME

if [ "x$MASTERHOST" == "x" ] || [ "x$MASTERDBPASS" == "x" ]; then
	DEBUG "ERROR: Invalid DB Replication configuration. ('data-server replica')";
	exit -1;
fi
###
### Read table list of master.
###

if [ "x$TABLES" == "x" ]; then
	TABLES=`mysql -h$MASTERHOST -u$MASTERDBUSER -p$MASTERDBPASS -e "select table_name from information_schema.tables where table_schema = 'ALDER' and Table_type = 'BASE TABLE'" -N -s $MASTERDBNAME`
fi

if [ "x$TABLES" == "x" ]; then
	STABLES=`mysql -h$SLAVEHOST -u$SLAVEDBUSER -p$SLAVEDBPASS -e "select table_name from information_schema.tables where table_schema = 'ALDER' and Table_type = 'BASE TABLE'" -N -s $SLAVEDBNAME`
else
	STABLES=$TABLES
fi

echo "TABLES: MASTER=`echo ${MASTERDBNAME}\(${TABLES}\) |wc -w` SLAVE=`echo ${SLAVEDBNAME}\(${STABLES}\) |wc -w`"

for tab in $TABLES
do
	# Check master tables.
	MTABHASH=`mysql -h$MASTERHOST -u$MASTERDBUSER -p$MASTERDBPASS -e "CHECKSUM TABLE $tab" -N -s $MASTERDBNAME | awk '{print $2}'`

	# Check slave tables.
	STABHASH=`mysql -h$SLAVEHOST -u$SLAVEDBUSER -p$SLAVEDBPASS -e "CHECKSUM TABLE $tab" -N -s $SLAVEDBNAME | awk '{print $2}'`

	# Check difference checksum.
	if [ "x$MTABHASH" != "x$STABHASH" ]; then 
		MTABROWS=`mysql -h$MASTERHOST -u$MASTERDBUSER -p$MASTERDBPASS -e "SELECT count(*) FROM $tab" -N -s $MASTERDBNAME 2> /dev/null`
		STABROWS=`mysql -h$SLAVEHOST -u$SLAVEDBUSER -p$SLAVEDBPASS -e "SELECT count(*) FROM $tab" -N -s $SLAVEDBNAME 2> /dev/null`

		firstdiff=false
		printf "TABLE=%-40s MASTER=%15s (%10d rows) SLAVE=%15s (%10d rows)\n" $tab $MTABHASH $MTABROWS $STABHASH $STABROWS

		# Synchronize forcefully
		if [ "x$DOSYNC" == "xTRUE" ] || [ "x$FORCEALL" == "xTRUE" ]; then
			if [ "x$FORCEALL" != "xTRUE" ]; then
				unset ans
				read -p "Synchronize focefully? [N/force/forceall] : " ans
			fi

			[[ "x$ans" == "xforceall" ]] && FORCEALL=TRUE

			if [ "x$ans" == "xforce" ] || [ "x$FORCEALL" == "xTRUE" ]; then
				forcesync $tab
			fi
		fi
	fi
done

DEBUG "Replication table checksum verifier DONE.";

