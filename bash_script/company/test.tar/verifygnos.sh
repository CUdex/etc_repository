#!/bin/bash

if [ "x$1" = "x" ] ; then
	echo "Usage: verifygnos.sh [image]"
	exit
fi

FSIZE=`ls -l $1 | awk '{print $5}'`
ISIZE=`expr $FSIZE - 256`

export OPENSSL_CONF=/dev/null

openssl x509 -in /usr/geni/geninetworks.crt -pubkey -noout > /tmp/public.pem

tail -c 256 $1 > /tmp/signature
dd if=$1 bs=$ISIZE count=1 of=/tmp/image.dat 2> /dev/null

openssl dgst -sha256 -verify /tmp/public.pem -signature /tmp/signature /tmp/image.dat

rm -f /tmp/signature
rm -f /tmp/image.dat
rm -f /tmp/public.pem
