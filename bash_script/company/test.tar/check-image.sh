#!/bin/bash
# 이미지 검사
if [ "x${GNTARGET}" == "x" ] ; then
	echo "no GNTARGET !!!"
	exit 1
fi
KERNELIMG=/disk/sys/boot/kernel.${GNTARGET}
INITRDIMG=/disk/sys/boot/initrd.img
ROOTFSIMG=/disk/sys/boot/rootfs.${GNTARGET}
WORKDIR=/tmp/check-image
WORKDIRINITRD=${WORKDIR}/INITRD
WORKDIRROOTFS=${WORKDIR}/ROOTFS

mkdir -p ${WORKDIR}
echo -n "Check KERNEL	.... wait"
if [ ! -f ${KERNELIMG} ] ; then
	echo "no ${KERNELIMG} !!!"
	exit 1
fi
echo -e "\b\b\b\b    OK"

echo -n "Check INITRD	.... wait"
if [ ! -f ${INITRDIMG} ] ; then
	echo "no ${INITRDIMG} !!!"
	exit 1
else
	cp ${INITRDIMG} /tmp/initrd.img.gz
	gzip -d /tmp/initrd.img.gz
	mkdir -p ${WORKDIRINITRD}
	mount -o loop /tmp/initrd.img ${WORKDIRINITRD}
	if [ $? -ne 0 ] ; then
		echo "INITRD problem ( cat not mount ) !!!"
		exit 1
	fi
	if [ ! -f ${WORKDIRINITRD}/genirc ] ; then
		echo "INITRD problem ( no genirc ) !!!"
		exit 1
	fi
	umount ${WORKDIRINITRD}
	rm -rf /tmp/initrd.img
fi
echo -e "\b\b\b\b    OK"

echo -n "Check ROOTFS	.... wait"
if [ ! -f ${ROOTFSIMG} ] ; then
	echo "no ${ROOTFSIMG} !!!"
	exit 1
else
	mkdir -p ${WORKDIRROOTFS}
	mount -o loop ${ROOTFSIMG} ${WORKDIRROOTFS}
	if [ $? -ne 0 ] ; then
		echo "ROOTFS problem ( cat not mount ) !!!"
		exit 1
	fi
	if [ ! -f ${WORKDIRROOTFS}/.version ] ; then
		echo "ROOTFS problem ( no .version ) !!!"
		exit 1
	else
		IMGVERSION=`cat ${WORKDIRROOTFS}/.version`
	fi
	umount ${WORKDIRROOTFS}
fi
rm -rf 
WORKVERSION=`cat /.version`
echo -e "\b\b\b\b    OK"
echo "WORKING VERSION : ${WORKVERSION}"
echo "CHECK   VERSION : ${IMGVERSION}"
