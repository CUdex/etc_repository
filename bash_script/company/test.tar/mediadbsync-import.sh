#!/bin/bash
# 매체관리 동기화 테이블 Import
LOCALCONF=/disk/sys/conf/local.conf
DSPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$DSPASS" == "x" ] ; then
        DSPASS=root123
fi
DBUSER=root
DBNAME=ALDER
TEMPPATH=/disk/data/temp
DBDUMPFILENAME=dbsync.dump

filename=${TEMPPATH}/${DBDUMPFILENAME}
	
/usr/mysql/bin/mysql -u${DBUSER} -p${DSPASS} -h dbserver ${DBNAME} < ${filename}
