#!/bin/bash
# tmp 디렉토리 정리

count=`find /tmp/jfree*  -mmin +2 | wc -l | sed 's/ //g'`
if [ "x${count}" != "x0" ] ; then
logger -t tmp-clear.sh "${count} jfree files delete"
find /tmp/jfree*  -mmin +2 -exec rm -f {} \; &> /dev/null
fi

