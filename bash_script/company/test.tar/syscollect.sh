#!/bin/sh

LOCALCONF=/disk/sys/conf/local.conf
IFLIST=`ifconfig -a  | grep 'Link encap' | awk '{print $1}'`
ISSUEID=

#
#
#

head()
{
	echo "<h5>$1</h5>" >> /tmp/sysinfo.htm
}

title()
{
	echo "<a href=\"#^$1^\">$1</a><br>" >> /tmp/sysinfo.htm
	echo "<h5>[[ $1 ]]</h5> <a name=\"^$1^\"></a>"  >> /tmp/sysinfo.tmp
}

execute()
{
	echo "<xmp>"  >> /tmp/sysinfo.tmp
	eval "$1" >> /tmp/sysinfo.tmp 2>&1
	echo "</xmp>"  >> /tmp/sysinfo.tmp
}

dircat()
{
	if [ -d $1 ] ; then
		execute "find $1 -maxdepth 1 -not -regex \".*\(name\|class\|ports\|handlers\|stats\)\" -type f -print -exec cat {} \;"
	fi
}

report()
{
	#
	# OS/System
	#
	echo "<head>" >> /tmp/sysinfo.htm
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" >> /tmp/sysinfo.htm
	echo "</head>" >> /tmp/sysinfo.htm
	
	head "OS/System"
	
	title 'DateTime'
	execute "date +'%Y/%m/%d %H:%M:%S'"
	
	title 'GenianOS'
	execute "cat /.version"
	
	title 'ModelName'
	execute "cat /var/etc/PLATFORM"
	
	title 'Uptime'
	execute "uptime"

	title 'Boot timestamp'
	execute "cat /proc/stat|grep btime"
	
	title 'Environment'
	execute "env"

	title 'Process List'
	execute "ps -eTo pid,spid,ppid,stat,user,c,pmem,sz,vsz,rss,tname,lstart,time,cmd"

	title 'Memory Information'
	execute "free"
	execute "cat /proc/meminfo"
	execute "cat /proc/slabinfo"

	title 'dmesg'
	execute "dmesg"

	if [ -f /var/log/old/messages.1 ] ; then
		title 'boot history'
		execute "grep 'CPU0:' /var/log/old/messages.1"
	fi
	
	if [ -f /var/log/messages ] ; then
		title 'message'
		execute "tail -1000 /var/log/messages"
	fi

	if [ -f /tmp/history.txt ] ; then
		title 'Command History'
		execute "cat /tmp/history.txt"
		rm -f /tmp/history.txt
	fi

	title 'lsof'

	LSOF=`lsof`
	TOTAL_NUM=`echo "$LSOF" | wc -l`
	CEN_NUM=`echo "$LSOF" | grep centerd | wc -l`
	SEN_NUM=`echo "$LSOF" | grep sensord | wc -l`
	HTTPD_NUM=`echo "$LSOF" | grep httpd | wc -l`

	execute "echo -n \"Total fd count : $TOTAL_NUM\""
	execute "echo -n \"centerd fd count : $CEN_NUM\""
	execute "echo -n \"sensord fd count : $SEN_NUM\""
	execute "echo -n \"httpd fd count : $HTTPD_NUM\""
	execute "echo \"$LSOF\""

	#
	# Backtrace 
	#
	
	head "Process stack"
	
	echo -n "Do you want to trace centerd ? (y/N) "
	read CTRACE 

	if [ "$CTRACE" == "y" ] || [ "$CTRACE" == "Y" ] ; then
		title 'centerd process stack'
		echo 'tracing centerd'
		execute 'showpstack centerd 2>1'
	fi

	echo -n "Do you want to trace sensord ? (y/N) "
	read STRACE 

	if [ "$STRACE" == "y" ] || [ "$STRACE" == "Y" ] ; then
		title 'sensord process stack'
		echo 'tracing sensord'
		execute 'showpstack sensord 2>1'
	fi

	#
	# Network
	#
	
	head "Network"
	
	title 'Interfaces'
	execute "ifconfig -a"
	
	#title 'Hardware Information'
	#lshw
	
	title 'Ethtool'
	for IFN in $IFLIST ; do
		execute "ethtool $IFN"
	done

	title 'IP Addresses'
	execute 'ip address'

	title 'IP Rule List'
	execute 'ip rule list'

	title 'Routing Table'
	execute 'ip route list table all'

	title 'Netstat'
	execute 'netstat -an'
	
	title 'iptables Filter Table'
	execute 'iptables -t filter --list'

	title 'iptables NAT Table'
	execute 'iptables -t nat --list'

	#
	# Disk
	#
	
	head "Disk"
	
	title 'Disk Information'
	execute "df -k"
	
	title 'Disk SMART Information'
	if [ "x$LOGDEV" != "x" ] ; then
		execute "echo $LOGDEV"
		execute "smartctl -a $LOGDEV"
	fi
	if [ "x$DBDEV" != "x" ] ; then
		execute "echo $DBDEV"
		execute "smartctl -a $DBDEV"
	fi

	if [ "x$PLATFORM" = "xGPC-3500-T20" ] ; then
		title 'RAID Status (3ware)'
		execute 'tw_cli info c0'
	fi
	
	#
	# Service
	#
	
	head "Service"
	
	if [ -f /var/run/httpd_status ] ; then
		title 'HTTPD status'
		execute "ftss /var/run/httpd_status"
	fi
	
	if [ -f /var/run/cache_status ] ; then
		title 'CACHED status'
		execute "ftss /var/run/cache_status"
	fi

	title 'httpd extra config'
	execute "cat /disk/sys/conf/httpd*.conf"

	title 'httpd error_log'
	execute "tail -1000 /disk/data/logs/httpd/error_log"
	
	title 'context.xml'
	execute "cat /disk/sys/conf/context.xml"
	
	title 'tomcat log'

	TOMCATPID=`cat /var/run/java.pid`
	kill -QUIT $TOMCATPID 

	execute "tail -1000 /disk/data/logs/tomcat/catalina.out"
	
	#
	# Genian
	#
	
	head "Genian"

	title '/disk/sys/conf'
	execute "ls -al /disk/sys/conf"
	
	title 'local.conf'
	execute "cat $LOCALCONF"

	title 'runsync'
	execute 'find /disk/data/DBSYNC/runsync* -printf "\nFILENAME: %p\n" -exec cat {} \;'

	title 'authsync.conf'
	execute 'find /disk/sys/conf/authsync* -printf "\nFILENAME: %p\n" -exec cat {} \;'
	
	title 'pre init script'
	execute "cat /disk/sys/conf/init.pre"
	
	title 'post init script'
	execute "cat /disk/sys/conf/init.post"
	
	title 'custom.sql'
	execute "cat /disk/sys/conf/custom.sql"
	
	title 'agent version'
	execute "cat /disk/data/agent/version.conf"

	title 'center critical/alert'
	execute "grep 'CRI|\|ALT|' /var/log/centerd"
	
	title 'sensor critical/alert'
	execute "grep 'CRI|\|ALT|' /var/log/sensord"

	title 'core reports'
	execute "cat /disk/data/core/old/report*"
	
	LSMODNAC=`lsmod | grep nac`
	if [ "x$LSMODNAC" == "x" ] ; then

		#
		# CLICK
		#

		head "CLICK"

		title "GlobalConfig"
		execute "cat /click/GLOBALCONFIG/globalconfig"

		title "ForceFailSafe"
		execute "cat /click/GLOBALCONFIG/forcefailsafe"

		title "Sensor Status"	
		for IFN in $IFLIST ; do
			execute "echo $IFN"

			PIF=`echo $IFN | awk -F'.' '{print $1}'`
			NUM=`echo $IFN | awk -F'.' '{print $2}'`
			if [ "x$NUM" = "x" ] ; then
				NUM=0
			fi
			DIRN=`echo "/click/SENSOR-$PIF-$NUM/SENSOR_MOD" | tr '-' '_'`

			if [ -d $DIRN ] ; then
				execute "echo $IFN"
				dircat "$DIRN/ARPPOISON"
				dircat "$DIRN/CWP"
				dircat "$DIRN/FILTER"
				dircat "$DIRN/NODEINFO"
			fi
		done

	else

		#
		# Enforcer
		#

		head "Enforcer"

		title "config"
		execute "cat /proc/nac/config"

		title "earlyrole"
		execute "cat /proc/nac/earlyrole"

		title "interface"
		execute "cat /proc/nac/interface"

		title "node"
		execute "cat /proc/nac/node"

		title "response_allowcnt"
		execute "cat /proc/nac/response_allowcnt"

		title "response_delay"
		execute "cat /proc/nac/response_delay"

		title "rolematch"
		execute "cat /proc/nac/rolematch"

		title "stat"
		execute "cat /proc/nac/stat"

		title "taccount_dest"
		execute "cat /proc/nac/taccount_dest"

		title "taccount_proto"
		execute "cat /proc/nac/taccount_proto"
	fi

	#
	# Database
	#
	
	head "Database"
	
	DSLOCAL=`cat $LOCALCONF | grep '^data-server=' | awk -F'=' '{print $2}'`
	DSREMOTE=`cat $LOCALCONF | grep '^data-server_ip='`
	DSPASS=`cat $LOCALCONF | grep '^data-server_password=' | awk -F'=' '{print $2}'`
	DSPORT=`cat $LOCALCONF | grep '^data-server_port=' | awk -F'=' '{print $2}'`
	TABLENAME=(Information)
	if [ "x$DSPASS" == "x" ] ; then
		DSPASS=root123
	fi
	if [ ${#DSPASS} == 64 ] ; then
		DSPASS=`/bin/aes256 -d $DSPASS`
	fi
	DSUSER=`cat $LOCALCONF | grep '^data-server_username=' | awk -F'=' '{print $2}'`
	if [ "x$DSUSER" == "x" ] ; then
		DSUSER=root
	fi
	if [ "x$DSPORT" == "x" ] ; then
		DSPORT=3306
	fi
	
	if [ "x$DSLOCAL" != "x" ] || [ "x$DSREMOTE" != "x" ] ; then
		title 'Database Table Information'
		execute "mysql -u $DSUSER --password=$DSPASS -P $DSPORT -h dbserver ALDER -te \"SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH from information_schema.TABLES WHERE TABLE_SCHEMA= 'ALDER' AND TABLE_TYPE='BASE TABLE'\""
	
		title 'Database Process Information'
		execute "mysql -u $DSUSER --password=$DSPASS -P $DSPORT -h dbserver ALDER -te \"SHOW FULL PROCESSLIST\""
	
		title 'Database Status Information'
		execute "mysql -u $DSUSER --password=$DSPASS -P $DSPORT -h dbserver ALDER -te \"SHOW GLOBAL STATUS\""

		title 'Database Variables'
		execute "mysql -u $DSUSER --password=$DSPASS -P $DSPORT -h dbserver ALDER -te \"SHOW VARIABLES\""

		title 'Database Policy Information'
		for ((i=0; i<${#TABLENAME[@]}; i++)); do
			execute "echo ========================= ${TABLENAME[i]} ========================="
			execute "mysql -u $DSUSER --password=$DSPASS -P $DSPORT -h dbserver ALDER -te \"SELECT * FROM ${TABLENAME[i]}\""
			done
	fi

	#
	# Log Server
	#
	
	head "Log Server"

	title 'elasticsearch.yml'
	execute "cat /var/elasticsearch/config/elasticsearch.yml"
}

#
# 
#

if [ "$0" != "///disk/data/new/syscollect.sh" ] ; then
	echo "Checking for update..."
	if [ ! -d /disk/data/new ] ; then
		mkdir -p /disk/data/new
	fi
	cd /disk/data/new
	wget --no-check-certificate -N --timeout=5 --tries=3 https://download.geninetworks.com/NAC/syscollect.sh &> /dev/null
	if [ -f syscollect.sh ] ; then
		chmod 755 ./syscollect.sh
		DIFF=`diff /usr/geni/tools/syscollect.sh ./syscollect.sh`

		if [ "x$DIFF" != "x" ] ; then
			echo Execute from /disk/data/new/syscollect.sh
			echo ''
			///disk/data/new/syscollect.sh $1
			exit
		fi
	fi
	echo Updated version not found
	echo ''
fi

echo -n "Do you want upload to GENIANS IMS ? (Y/n) "
read UPLOAD

if [ "$UPLOAD" != "n" ] && [ "$UPLOAD" != "N" ] ; then
    echo -n "Enter GENIANS IMS Issue ID: "
    read ISSUEID

    echo -n "Enter GENIANS IMS Username: "
    read USERNAME

    echo -n "Enter Comment: "
    read COMMENT
fi

if [ ! -d /disk/data/logs ] ; then
	mkdir -p /disk/data/logs
fi

rm -f /tmp/sysinfo.htm
rm -f /tmp/sysinfo.tmp

report

cat /tmp/sysinfo.tmp >> /tmp/sysinfo.htm
mv /tmp/sysinfo.htm /disk/data/logs
rm -f /tmp/sysinfo.tmp

MAC=`cat /disk/sys/conf/.eth0`
FNAME=$MAC-`date +%Y%m%d%H%M%S`.zip

rm -f /disk/data/temp/$MAC*.zip

/usr/geni/tools/cleanup-oldfiles.sh delete &> /dev/null

cd /disk/data/logs

if [ "$1" = "full" ] ; then
	zip -r /disk/data/temp/$FNAME sysinfo.htm * -x system/old/.crond* system/old/.openvpn* system/scanraw/ system/agent/ system/updown/
elif [ "$1" = "nolog" ] ; then
	zip /disk/data/temp/$FNAME sysinfo.htm
elif [ "$1" = "current" ] ; then
	zip /disk/data/temp/$FNAME sysinfo.htm system/centerd system/sensord system/vrrpd system/click system/messages system/gnlogin system/procmond system/authsync system/adsmon.log system/radius.log system/log.winbindd httpd/* mysqld/* tomcat/* elasticsearch/* /disk/sys/kdump/*
else

	echo -n "Do you want to collect agent logs ? (y/N) "
	read AGENT 

	if [ "$AGENT" == "y" ] || [ "$AGENT" == "Y" ] ; then
		zip /disk/data/temp/$FNAME sysinfo.htm system/centerd system/sensord system/vrrpd system/click system/messages system/gnlogin system/procmond system/authsync system/adsmon.log system/radius.log system/log.winbindd system/old/*.1 httpd/* httpd/old/*.1 httpd/old/*log-* mysqld/* mysqld/old/*.1 mysqld/old/*log-* mysqld/old/mysqld.*-* tomcat/* tomcat/old/*.1 tomcat/old/catalina.out-* elasticsearch/* elasticsearch/old/*.1 /disk/sys/kdump/* system/agent/*
	else 
		zip /disk/data/temp/$FNAME sysinfo.htm system/centerd system/sensord system/vrrpd system/click system/messages system/gnlogin system/procmond system/authsync system/adsmon.log system/radius.log system/log.winbindd system/old/*.1 httpd/* httpd/old/*.1 httpd/old/*log-* mysqld/* mysqld/old/*.1 mysqld/old/*log-* mysqld/old/mysqld.*-* tomcat/* tomcat/old/*.1 tomcat/old/catalina.out-* elasticsearch/* elasticsearch/old/*.1 /disk/sys/kdump/*
	fi
fi
rm -f /disk/data/logs/sysinfo.htm
if [ $? != 0 ] ; then
    echo "Compression failed."
    exit
fi

FSIZE=`wc -c /disk/data/temp/$FNAME | awk -F' ' '{print $1}'`

if [ "$UPLOAD" = "n" ] || [ "$UPLOAD" = "N" ] ; then
    echo ""
    echo "Filename: /disk/data/temp/$FNAME"
    echo "Size: $FSIZE"
    echo ""
    exit
fi

echo ""
echo "Sending sysinfo to GENIANS..."

wget -q --timeout=5 --tries=3 --no-check-certificate --post-file=/disk/data/temp/$FNAME "https://geniupdate.geninetworks.com/bp/sc/?NAME=SYSCOLLECT&FN=$FNAME&MAC=$MAC&COMMENT=$COMMENT&issueID=$ISSUEID&USERNAME=$USERNAME" --output-document=/tmp/syscollect.result.html
if [ $? -ne 0 ] ; then
    echo "Upload failed. check network status"
fi

echo "Done"

echo ""
echo "Filename: /disk/data/temp/$FNAME"
echo "Size: $FSIZE"
echo ""

