#!/bin/sh

if [ "x$1" = "x" ]; then
    echo "Usage: upload-file.sh [filename]"
    exit
fi

echo -n "Enter GENIANS IMS Issue ID (optional): "
read ISSUEID
echo -n "Enter Comment: "
read COMMENT

ISZIP=`echo $1 | grep zip`

if [ "x$ISZIP" = "x" ]; then
    echo "File is not compressed. compress now..."
    FNAME=/disk/data/temp/$1.zip
    rm -f $FNAME
    zip -j $FNAME $1
else
    FNAME=$1
fi

CUTFN=`echo $FNAME | awk -F'/' '{print $NF}'`

MAC=`cat /disk/sys/conf/.eth0`
DATE=`date +%Y%m%d%H%M%S`

echo ""
echo "Sending sysinfo to GENIANS..."

./wget -q --no-check-certificate -T 30 --post-file=$FNAME "https://geniupdate.geninetworks.com/bp/sc/?NAME=FILE&FN=$CUTFN&MAC=$MAC&COMMENT=$COMMENT&IsueID=$ISSUEID" --output-document=/tmp/uplaodfile.html --progress=dot
if [ $? -ne 0 ] ; then
    echo "Upload failed. check network status"
fi

if [ "x$ISZIP" = "x" ]; then
    rm -f $FNAME
fi

echo "Done"
