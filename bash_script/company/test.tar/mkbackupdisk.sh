#!/bin/bash

if [ "x$1" == "x" ] ; then
	echo "Usage: mkbackupdir.sh [device]"
	exit 1
fi

INUSE=`df -k | grep ${1}`

if [ "x$INUSE" != "x" ] ; then
	echo "%%% device is busy"
	exit 1
fi

/bin/sfdisk -uM --force $1 &> /tmp/.mkbackup.log << EOF
,,83
EOF

/bin/udevstart
/bin/mke2fs -j ${1}1
/bin/tune2fs -i 0 -c 0 ${1}1
