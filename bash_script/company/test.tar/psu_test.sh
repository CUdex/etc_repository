#!/bin/bash

#Environment argument
VERSION="V1.3.1"
CONF=../conf


# Set configurations to get PSU state.
function init_environment(){
	I2C_BUS=`i2cdetect -l|grep -i i801|awk '{print $1}'|awk -F- '{print $2}'`
	I2C_DET_ADDR=2d
	I2C_ADDR=0x$I2C_DET_ADDR
	PSU_REG=0x92
	TEMPERATURE_REG=0x14
	VOLTAGE_REG_3=0x10
	VOLTAGE_REG_5=0x11
	VOLTAGE_REG_12=0x12
}

function print_help(){
	#clear
	echo ""
	echo "Usage of PSU status functionality ($VERSION) :"
	echo -e "psu_test.sh [options]\n"
	echo "[options]:"
	echo "  -P  => Reading PSU present status."
	echo "  -T  => Reading PSU temperature status."
	echo "  -V  => Reading PSU voltage status."
	echo ""
}

# Check if the i2c address can be detected.
function psu_bus_check() {
	#Get SMBus adapter
	adapter=$(i2cdetect -l | awk '{print $2}')
	i=0
	for n in  $adapter
	do
		if [ "$n" == "smbus" ]; then
			I2C_BUS=$i
			break
		else
			i=$[$i+1];
		fi
	done

	echo Y | i2cdetect $I2C_BUS 2>/dev/null | grep $I2C_DET_ADDR >/dev/null
	[ "$?" -ne 0 ] \
		&& echo "ERROR: Can't detect I2C address $I2C_ADDR." && exit 1

}

# Get PSU Voltage from CR92.
function psu_state_volt_check() {
	VALUE=$(echo Y | i2cget $I2C_BUS $I2C_ADDR $VOLTAGE_REG_3 2>/dev/null)
	VALUE=$((VALUE*78125*2/100000))
	printf "The 3.3V of the power supply: %d.%d%dV\n" $((VALUE/100)) $(((VALUE/10)%10)) $((VALUE%10))
	VALUE=$(echo Y | i2cget $I2C_BUS $I2C_ADDR $VOLTAGE_REG_5 2>/dev/null)
	VALUE=$((VALUE*78125*6/100000))
	printf "The 5V of the power supply: %d.%d%dV\n" $((VALUE/100)) $(((VALUE/10)%10)) $((VALUE%10))
	VALUE=$(echo Y | i2cget $I2C_BUS $I2C_ADDR $VOLTAGE_REG_12 2>/dev/null)
	VALUE=$((VALUE*78125*11/100000))
	printf "The 12V of the power supply: %d.%d%dV\n" $((VALUE/100)) $(((VALUE/10)%10)) $((VALUE%10))
}

# Get PSU Temperature from CR92.
function psu_temp_state_check() {
	VALUE=$(echo Y | i2cget $I2C_BUS $I2C_ADDR $TEMPERATURE_REG 2>/dev/null)
	printf "The temperature of the power supply: %dC\n" $VALUE
}

# Get PSU state from CR92.
# If bit 0=0 then PSU#1 is not present else PSU#1 is present.
# If bit 1=0 then PSU#2 is not present else PSU#2 is present.
function psu_state_check() {
	STATUS=$(echo Y | i2cget $I2C_BUS $I2C_ADDR $PSU_REG 2>/dev/null)
	if [ "$SKIP_PSU1_PRESENT_CHECK" != 1 ] ; then
		if [ $((STATUS & 1)) -eq 1 ]; then
			echo "PSU#1 is present."
		else
			echo "PSU#1 is not present."
		fi
	fi
	if [ "$SKIP_PSU2_PRESENT_CHECK" != 1 ] ; then
		if [ $((STATUS & 2)) -eq 2 ]; then
			echo "PSU#2 is present."
		else
			echo "PSU#2 is not present."
		fi
	fi
}

init_environment
psu_bus_check
while getopts "dhHTVPM:" opt
do
	case $opt in
	M)
		MODEL=$OPTARG
	;;
	T)
		psu_temp_state_check
	;;
	P)
		[ "$MODEL" ] && source $CONF/$MODEL
		psu_state_check
	;;
	V)
		psu_state_volt_check
	;;
	h|H)
		print_help
	;;
	*)
		echo "Invalid option $opt"
		print_help
	;;
	esac
done
[ "$OPTIND" = 1 ] && print_help
