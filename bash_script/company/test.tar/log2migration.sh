#!/bin/bash

LOCALCONF=/disk/sys/conf/local.conf

DSPASS=`cat $LOCALCONF | grep '^data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$DSPASS" == "x" ] ; then
	DSPASS=root123
fi
if [ ${#DSPASS} == 64 ] ; then
	DSPASS=`/bin/aes256 -d $DSPASS`
fi
DSUSER=`cat $LOCALCONF | grep '^data-server_username=' | awk -F'=' '{print $2}'`
if [ "x$DSUSER" == "x" ] ; then
    DSUSER=root
fi

DSPORT=`cat $LOCALCONF | grep 'data-server_port=' | awk -F'=' '{print $2}'`
if [ "x$DSPORT" == "x" ] ; then
    DSPORT=3306
fi

L2MIG=`mysql -u $DSUSER --password=$DSPASS -h dbserver -P $DSPORT -te "SELECT ValueData FROM Information WHERE KeyName='LOG2Migration'" ALDER`
if [ "x$L2MIG" != "x" ] ; then
	echo LOG2 migration already completed.
	exit
fi

L2SZ=`mysql -u $DSUSER --password=$DSPASS -h dbserver -P $DSPORT -E -te "SELECT count(*) FROM LOG2" ALDER | grep count | awk '{print $2}'`
if [ "x$L2SZ" = "x" ] ; then
	echo Internal error
	exit
fi
if [ "x$L2SZ" = "x0" ] ; then
	echo LOG2 is empty
	exit
fi

MEMSIZE=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
if [ $MEMSIZE -gt 4000000 ] ; then
	MEMOPT="-Xms3g -Xmx3g"
elif [ $MEMSIZE -gt 2000000 ] ; then
	MEMOPT="-Xms1g -Xmx1g"
else
	MEMOPT="-Xms512m -Xmx512m"
fi

mysql -u $DSUSER --password=$DSPASS -h dbserver -P $DSPORT -te "INSERT INTO Information (KeyName, ValueType, ValueData) VALUE ('LOG2Migration', 3, NOW())" ALDER

java $MEMOPT -cp "/usr/tomcat/webapps.base/mc2/WEB-INF/lib/*:/usr/tomcat/lib/*" com.geninetworks.log2migration.Log2Migration $DSUSER $DSPASS $DSPORT

echo "Migration completed"
