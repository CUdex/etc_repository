#!/bin/bash

if [ "x$1" = "x" ] ; then
	echo "Invalid Parameters"
	exit 1
fi

# 배포파일 검증기능은 신뢰하는 인증서가 존재하는 경우에만 수행한다.

if [ ! -f /disk/sys/conf/trusted/issuer.pem ] || [ ! -f /disk/sys/conf/trusted/signer.pem ] ; then
	echo -n "Successfully Verified"
	exit 0
fi

export OPENSSL_CONF=/dev/null

DIRNAME=/tmp/$RANDOM

rm -rf $DIRNAME
mkdir $DIRNAME
cd $DIRNAME

/bin/osslsigncode verify $1 > /dev/null

if [ ! -f issuer.pem ] || [ ! -f signer.pem ] ; then
	# Authenticode signature not found
	echo -n "sign_K1"
	cd /
	rm -rf $DIRNAME
	exit 1
fi

DIFF=`diff signer.pem /disk/sys/conf/trusted/signer.pem`
if [ "x$DIFF" != "x" ] ; then
	# File is not signed by trusted CA
	echo -n "sign_K2"
	cd /
	rm -rf $DIRNAME
	exit 1
fi

SUBJ1=`openssl x509 -in /disk/sys/conf/trusted/issuer.pem -subject | grep subject=`
SUBJ2=`openssl x509 -in issuer.pem -subject | grep subject=`
if [ "x$SUBJ1" != "x$SUBJ2" ] ; then
	# File is not signed by trusted Issuer
	echo -n "sign_K3"
	cd /
	rm -rf $DIRNAME
	exit 1
fi

echo -n "Successfully Verified"

rm -rf $DIRNAME
exit 0;
