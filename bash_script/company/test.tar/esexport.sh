#!/bin/bash

# command 
CURL=/bin/curl

# function
rawurlencode() {
  local string="${1}"
  local strlen=${#string}
  local encoded=""
  local pos c o

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded="${encoded}${o}"
  done
  echo "${encoded}"    # You can either set a return variable (FASTER)
  REPLY="${encoded}"   #+or echo the result (EASIER)... or both... :p
}
# parameter
OUTPUTFILE=""
HOST="http://logserver"
LOCALCONF=/disk/sys/conf/local.conf
PORT=`cat $LOCALCONF | grep '^log-server_http-port=' | awk -F'=' '{print $2}'`
if [ "x$PORT" == "x" ] ; then
  PORT="9200"
fi
EXTENSION="csv"
INDICES="nac*/"
TYPE=""
QUERY=""

while [[ $# -gt 1 ]]
do
key=$1
case $key in
    -o|--output)
    OUTPUTFILE="$2"
    shift
    ;;
    -h|--host)
    HOST="$2"
    shift # past argument
    ;;
    -p|--port)
    PORT="$2"
    shift # past argument
    ;;
    -i|--indices)
    INDICES="$2"
    shift # past argument
    ;;  
    -t|--type)
    TYPE="$2"
    shift # past argument
    ;;
    -e|--extension)
    EXTENSION="$2"
    shift # past argument
    ;;
    -qf|--queryfile)
    TEMP=`cat $2`
    QUERY=`rawurlencode "$TEMP"`
    shift # past argument
    ;;
    -q|--query)
    QUERY=`rawurlencode "$2"`
    shift
    ;;
esac
shift # past argument or value
done

URL="$HOST:$PORT/$INDICES$TYPE/_data?format=$EXTENSION&source=$QUERY"

if [ "x$OUTPUTFILE" == "x" ] || [ "x$QUERY" == "x" ] || [ "x$INDICES" == "x" ] ; then
  echo "Not enough parameters."
  exit 1
fi

if [ "$EXTENSION" != "csv" ] && [ "$EXTENSION" != "xls" ] && [ "$EXTENSION" != "xlsx" ] ; then
  echo "Invalid output format"
  exit 1
fi

if [ "x$TYPE" == "x" ] ; then
  URL="$HOST:$PORT/$INDICES/_data?format=$EXTENSION&source=$QUERY"
else
  URL="$HOST:$PORT/$INDICES/$TYPE/_data?format=$EXTENSION&source=$QUERY"
fi

$CURL -o $OUTPUTFILE -XGET "$URL"

exit 0
