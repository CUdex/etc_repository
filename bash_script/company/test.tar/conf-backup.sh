#!/bin/bash -l
echo -n 'Start backup...'

if [ -z $1 ]; then
	/usr/geni/centerd -j all > /dev/null
else
	/usr/geni/centerd -j $1 > /dev/null
fi

echo 'Finished.'

exit 0

# 설정 백업
OLDPATH=`pwd`
DBUSER=root
LOCALCONF=/disk/sys/conf/local.conf
DBPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$DBPASS" == "x" ] ; then
	DBPASS=root123
fi
DBNAME=ALDER
VERSION=`cat /.version | awk -F '-' '{print $4}'`
DBBACKUPDATE=`date +%Y%m%d-%H%M%S`
DBBACKUPPATH=/backup
DBBACKUPFILENAME=${DBNAME}-${VERSION}-${DBBACKUPDATE}.sql
CONFBACKUPDIRNAME=${DBNAME}-${VERSION}-${DBBACKUPDATE}
DBPATH="/disk/data/mysql/ALDER"

if [ ! -d /disk/sys/conf ] ; then
	echo "no conf dir ( /disk/sys/conf ) !!!!"
	exit 1
fi

if [ ! -d ${DBBACKUPPATH} ] ; then
	echo "no backup dir ( /backup ) !!!!"
	exit 1
fi

if [ ! -d ${DBBACKUPPATH}/${CONFBACKUPDIRNAME} ] ; then
	mkdir -p ${DBBACKUPPATH}/${CONFBACKUPDIRNAME}
fi
echo -n "Now conf file backup start	..... Please wait "
cp -rf /disk/sys/conf ${DBBACKUPPATH}/${CONFBACKUPDIRNAME}
echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "

if [ -f /disk/data/agent/GnAgent/GnInstall.exe ] ; then
echo -n "Now agent file backup start	..... Please wait "
cp -rf /disk/data/agent ${DBBACKUPPATH}/${CONFBACKUPDIRNAME}
echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "
fi

echo -n "Now custom file backup start	..... Please wait "
cp -rf /disk/data/custom ${DBBACKUPPATH}/${CONFBACKUPDIRNAME}
echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "

filename=${DBBACKUPPATH}/${CONFBACKUPDIRNAME}/${DBBACKUPFILENAME}
if [ ! -d ${DBBACKUPPATH} ] ; then
	mkdir -p ${DBBACKUPPATH}
fi
echo -n "Now DB backup start		..... Please wait "
	
/usr/mysql/bin/mysqldump -u ${DBUSER} -p${DBPASS} -R -h dbserver ${DBNAME} > ${filename}
/usr/mysql/bin/mysql -u ${DBUSER} -p${DBPASS} -h dbserver -e "FLUSH TABLE"

echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "

echo -n "Now compress backup file 	..... Please wait "
cd ${DBBACKUPPATH}
tar czvf ${CONFBACKUPDIRNAME}.tar.gz ${CONFBACKUPDIRNAME} &> /dev/null
cd ${OLDPATH}
echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "

echo -n "Now delete temp files		..... Please wait "
if [ "x${CONFBACKUPDIRNAME}" != "x" ] ; then
	rm -rf ${DBBACKUPPATH}/${CONFBACKUPDIRNAME} &> /dev/null
fi
echo -e "\b\b\b\b\b\b\b\b\b\b\b\bComplete                        "
echo backup name is ${CONFBACKUPDIRNAME}
