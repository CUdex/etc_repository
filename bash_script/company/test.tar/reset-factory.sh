#!/bin/sh

echo    "!!! WARNNIGN WARNNING WARNNING WARNNING WARNNING WARNNING !!!"
echo    ""
echo    "ALL DATA WILL BE ERASED (DATABASE, CONFIG, BACKUP)"
echo    ""
echo -n "Are you sure to reset factory default (with reboot) (y/N) ? "
read ask

if [ "x$ask" != "xy" ] ; then
	exit
fi

echo -n "Please type 'factory reset' for process: "
read ask

if [ "x$ask" != "xfactory reset" ] ; then
	exit
fi

/etc/init.d/alder stop

rm -rf /disk/sys/conf/*

cp /etc/defs/hosts /etc/hosts

rm -rf /disk/data/*
mkdir /disk/data/tmp
chmod 1777 /disk/data/tmp

reboot
