#!/bin/bash

if [ -f /disk/sys/conf/logrotate.conf ] ; then
	/bin/logrotate $1 --state=/var/lib/logrotate.status /disk/sys/conf/logrotate.conf
else
	/bin/logrotate $1 --state=/var/lib/logrotate.status /etc/logrotate.conf
fi
