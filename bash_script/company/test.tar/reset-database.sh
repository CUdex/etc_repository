#!/bin/sh

echo -n "Are you sure to reset database (y/N) ? "
read ask

if [ "x$ask" != "xy" ] ; then
	exit
fi

echo -n "Please type 'database reset' for process: "
read ask

if [ "x$ask" != "xdatabase reset" ] ; then
    exit
fi

/etc/init.d/alder stop

rm -rf /disk/data/elasticsearch
rm -rf /disk/data/mysql
rm -f /disk/sys/conf/custom.sql
rm -f /disk/sys/conf/customview.sql

if [ "x$SSDEV" != "x" ] ; then
	rm -rf /disk/data/ssdev/elasticsearch
	rm -rf /disk/data/ssdev/mysql
fi

/etc/init.d/alder start
