#!/bin/bash
cmdname=`basename ${0}`

# help 를 출력한다.
if [ "x${1}" == "x-h" ]; then
echo "
${cmdname}		: show old files
${cmdname} delete	: delete old files
${cmdname} -h		: help
"
	exit
fi

# arg delete 이면 삭제 flag 를 켠다.
if [ "x${1}" == "xdelete" ]; then
	delete="YES"
fi




# 사용하지 않는 디렉토리 삭제
filename="/disk/data/logs/genian"
if [ -d ${filename} ] ; then                                                                                             
        echo ${filename}                                                                                               
	if [ "x${delete}" == "xYES" ] ; then
		rm -rf ${filename}
		logger -t ${cmdname} "${filename} delete"
	fi
fi                                                                                                                                  


# 사용하지 않는 파일 삭제
filename="/disk/sys/conf/syslog-ng.conf.REMOTE"
if [ -f ${filename} ] ; then                                                                                             
        echo ${filename}                                                                                               
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${filename}
		logger -t ${cmdname} "${filename} delete"
	fi
fi                                                                                                                                  



# 이미지의 .old 파일을 삭제
filename="/disk/sys/boot/rootfs.${GNTARGET}.old"
if [ -f ${filename} ] ; then                                                                                             
        echo $filename                                                                                               
	if [ "x${delete}" == "xYES" ] ; then
		rm -f $filename
		logger -t ${cmdname} "$filename delete"
	fi
fi                                                                                                                                  

# 로그항목중 30일 이상된 로그 삭제
day=30
for hf in `find /disk/data/logs/httpd/old -mtime +${day}`
do
	echo $hf
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${hf}
		logger -t ${cmdname} "${day} days old log ${hf} delete"
	fi
done
for mf in `find /disk/data/logs/mysqld/old -mtime +${day}`
do
	echo $mf
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${mf}
		logger -t ${cmdname} "${day} days old log ${mf} delete"
	fi
done
for tf in `find /disk/data/logs/tomcat/old -mtime +${day}`
do
	echo $tf
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${tf}
		logger -t ${cmdname} "${day} days old log ${tf} delete"
	fi
done
for sf in `find /disk/data/logs/system/old -mtime +${day}`
do
	echo ${sf}
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${sf}
		logger -t ${cmdname} "${day} days old log ${sf} delete"
	fi
done
for tf in `find /disk/data/logs/elasticsearch/old -mtime +${day}`
do
	echo $tf
	if [ "x${delete}" == "xYES" ] ; then
		rm -f ${tf}
		logger -t ${cmdname} "${day} days old log ${tf} delete"
	fi
done


# 중복다운로드된 patch 파일 삭제
PATCHBASEPATH=/disk/data/patches
hex="0 1 2 3 4 5 6 7 8 9 A B C D E F"

for first in ${hex}
do
        for second in ${hex}
        do
                ppath=${PATCHBASEPATH}/${first}${second}
                files=`ls -1 ${ppath} | grep -E ".[0-9]+$"`
                for filename in ${files}
                do
                	echo ${ppath}/${filename}
			if [ "x${delete}" == "xYES" ] ; then
				rm -f ${ppath}/${filename}
				logger -t ${cmdname} "patches ${ppath}/${filename} delete"
			fi
                done
        done
done



# 사용되지 않는 파일들을 삭제
rm -f /disk/data/patches/index.ht*
rm -f /disk/data/patches/*/index.ht*
rm -f /disk/sys/boot/initrd.img.old &> /dev/null
rm -f /disk/sys/boot/kernel.CENTER.old &> /dev/null
rm -f /disk/sys/boot/kernel.SENSOR.old &> /dev/null
rm -f /disk/sys/boot/rootfs.CENTER.old &> /dev/null
rm -f /disk/sys/boot/rootfs.SENSOR.old &> /dev/null
rm -rf /disk/sys/conf/nmap &> /dev/null
rm -rf /disk/sys/conf/pldata01 &> /dev/null
rm -f /disk/sys/conf/enterprise-oids &> /dev/null
rm -f /disk/sys/conf/http-os-fingerprints &> /dev/null
rm -f /disk/sys/conf/nic-oskeys &> /dev/null
rm -f /disk/sys/conf/nic-platforms &> /dev/null
rm -f /disk/sys/conf/nmap-services &> /dev/null
