#!/bin/bash
# 매체관리 동기화 테이블 Export
LOCALCONF=/disk/sys/conf/local.conf
DSPASS=`cat $LOCALCONF | grep 'data-server_password=' | awk -F'=' '{print $2}'`
if [ "x$DSPASS" == "x" ] ; then
        DSPASS=root123
fi
DBUSER=root
DBNAME=ALDER
DUMPTABLE="MEDIALIST USER CONF_USER CustomData"
DBDUMPPATH=/disk/data/custom
DBDUMPFILENAME=dbsync.dump

filename=${DBDUMPPATH}/${DBDUMPFILENAME}
	
/usr/mysql/bin/mysqldump -u${DBUSER} -p${DSPASS} -h dbserver ${DBNAME} ${DUMPTABLE} -r ${filename}
